"""Utility scripts for email attachment processor."""

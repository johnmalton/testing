#!/usr/bin/env python3
"""
Email Ingestion Script
Fetches unread emails and stores attachments.

Usage:
    python scripts/fetch_emails.py

Schedule with cron (every 5 minutes):
    */5 * * * * cd /path/to/project && python scripts/fetch_emails.py >> logs/emails.log 2>&1
"""
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

import time
from datetime import datetime, timezone
from core.config import settings
from services.email_service import email_service


def main():
    """Main function."""
    print("=" * 70)
    print("Email Ingestion")
    print("=" * 70)
    print(f"Timestamp: {datetime.now(timezone.utc).isoformat()}")
    print(f"Mailbox: {settings.MAILBOX_EMAIL}")
    print(f"Folder: {settings.MAILBOX_FOLDER}")
    print(f"Max emails: {settings.MAX_EMAILS_PER_FETCH}")
    print("-" * 70)
    
    start_time = time.time()
    
    try:
        stats = email_service.process_emails()
        
        duration = time.time() - start_time
        
        print("-" * 70)
        print("Results:")
        print(f"  Emails processed: {stats['emails_processed']}")
        print(f"  Attachments saved: {stats['attachments_saved']}")
        print(f"  Errors: {stats['errors']}")
        print(f"  Duration: {duration:.2f} seconds")
        print("-" * 70)
        
        if stats['errors'] > 0:
            print("⚠ Completed with errors")
        else:
            print("✓ Completed successfully")
        
    except Exception as e:
        print(f"✗ Error: {e}")
        sys.exit(1)
    
    print("=" * 70)


if __name__ == "__main__":
    main()

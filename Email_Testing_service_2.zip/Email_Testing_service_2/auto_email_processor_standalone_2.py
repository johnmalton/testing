#!/usr/bin/env python3
"""
Standalone Automated Email Processing Script
Uses ONLY requests library - no external dependencies

Features:
- Fetches emails directly from Microsoft Graph API
- Processes and saves attachments
- Forwards to agent via REST API
- Health monitoring
- Auto token refresh
- Detailed logging

Usage:
    python scripts/auto_email_processor_standalone.py
"""
import os
import sys
import time
import json
import base64
import hashlib
import threading
from pathlib import Path
from datetime import datetime, timezone
import requests

# Load .env file if available
try:
    from dotenv import load_dotenv
    print("Successfully.............")
    # Try to load .env from same directory as script
    env_path = Path(__file__).parent / '.env'
    if env_path.exists():
        load_dotenv(env_path)
        print(f"Loaded configuration from: {env_path}")
    else:
        print(f"WARNING: .env file not found at: {env_path}")
        print(f"WARNING: Using environment variables or defaults")
except ImportError:
    print("WARNING: python-dotenv not installed, using environment variables only")
    print("  Install with: pip install python-dotenv")


class StandaloneEmailProcessor:
    """Fully standalone email processor using only requests library."""
    
    # Configuration (load from environment or hardcode for testing)
    API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:1948")
    API_KEY = os.getenv("API_KEY", "your-api-key-here")
    
    # Azure AD Configuration
    AZURE_TENANT_ID = os.getenv("AZURE_TENANT_ID", "")
    AZURE_CLIENT_ID = os.getenv("AZURE_CLIENT_ID", "")
    AZURE_CLIENT_SECRET = os.getenv("AZURE_CLIENT_SECRET", "")
    
    # Email Configuration
    MAILBOX_EMAIL = os.getenv("MAILBOX_EMAIL", "")
    MAILBOX_FOLDER = os.getenv("MAILBOX_FOLDER", "Inbox")
    MAX_EMAILS_PER_FETCH = int(os.getenv("MAX_EMAILS_PER_FETCH", "50"))
    
    # Storage
    ATTACHMENT_PATH = os.getenv("ATTACHMENT_PATH", "attachments")
    TOKEN_FILE = os.getenv("TOKEN_FILE", "config/token.json")
    
    # Graph API
    GRAPH_API = "https://graph.microsoft.com/v1.0"
    TOKEN_ENDPOINT = "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"
    
    def __init__(self):
        """Initialize processor."""
        self.cycle_count = 0
        self.total_emails_processed = 0
        self.total_attachments_forwarded = 0
        self.running = True
        
        # Ensure directories exist
        Path(self.ATTACHMENT_PATH).mkdir(parents=True, exist_ok=True)
        Path(self.TOKEN_FILE).parent.mkdir(parents=True, exist_ok=True)
        
        # Token management
        self.access_token = None
        self.token_expires_at = 0
        self.token_refresh_timer = None
        
        # Load or acquire token
        self.load_or_acquire_token()
        
        # Start token refresh timer
        self.start_token_refresh_timer()
    
    # ========================================================================
    # LOGGING
    # ========================================================================
    
    def log(self, message: str, level: str = "INFO"):
        """Print timestamped log message."""
        timestamp = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
        symbols = {
            "INFO": "[INFO]",
            "SUCCESS": "[SUCCESS]",
            "ERROR": "[ERROR]",
            "WARNING": "[WARNING]",
            "EMAIL": "[EMAIL]",
            "AGENT": "[AGENT]",
            "HEALTH": "[HEALTH]",
            "TOKEN": "[TOKEN]"
        }
        symbol = symbols.get(level, "[LOG]")
        print(f"[{timestamp}] {symbol} {message}")
    
    # ========================================================================
    # TOKEN MANAGEMENT
    # ========================================================================
    
    def load_or_acquire_token(self):
        """Load token from file or acquire new one."""
        # Try to load from file
        if Path(self.TOKEN_FILE).exists():
            try:
                with open(self.TOKEN_FILE, 'r') as f:
                    token_data = json.load(f)
                    self.access_token = token_data.get('access_token')
                    self.token_expires_at = token_data.get('expires_at', 0)
                    
                    # Check if token is still valid
                    if self.token_expires_at > (time.time() + 300):
                        self.log("Loaded valid token from file", "TOKEN")
                        return
            except Exception as e:
                self.log(f"Failed to load token: {e}", "WARNING")
        
        # Acquire new token
        self.acquire_token()
    
    def acquire_token(self):
        """Acquire new access token from Azure AD."""
        self.log("Acquiring new access token...", "TOKEN")
        
        # Validate configuration
        if not self.AZURE_TENANT_ID or not self.AZURE_CLIENT_ID or not self.AZURE_CLIENT_SECRET:
            error_msg = "Azure AD credentials not configured! Please set AZURE_TENANT_ID, AZURE_CLIENT_ID, and AZURE_CLIENT_SECRET"
            self.log(error_msg, "ERROR")
            raise Exception(error_msg)
        
        endpoint = self.TOKEN_ENDPOINT.format(tenant=self.AZURE_TENANT_ID)
        
        data = {
            'grant_type': 'client_credentials',
            'client_id': self.AZURE_CLIENT_ID,
            'client_secret': self.AZURE_CLIENT_SECRET,
            'scope': 'https://graph.microsoft.com/.default'
        }
        
        try:
            response = requests.post(
                endpoint,
                data=data,
                headers={'Content-Type': 'application/x-www-form-urlencoded'},
                timeout=30
            )
            
            if response.status_code == 200:
                token_response = response.json()
                self.access_token = token_response['access_token']
                expires_in = token_response.get('expires_in', 3600)
                self.token_expires_at = time.time() + expires_in
                
                # Save to file
                token_data = {
                    'access_token': self.access_token,
                    'token_type': token_response.get('token_type', 'Bearer'),
                    'expires_in': expires_in,
                    'expires_at': self.token_expires_at,
                    'expires_at_iso': datetime.fromtimestamp(self.token_expires_at, tz=timezone.utc).isoformat(),
                    'acquired_at': datetime.now(timezone.utc).isoformat()
                }
                
                with open(self.TOKEN_FILE, 'w') as f:
                    json.dump(token_data, f, indent=2)
                
                self.log(f"Token acquired successfully! Expires in {expires_in}s", "SUCCESS")
            else:
                # Try to parse JSON error, fallback to text
                try:
                    error = response.json()
                    error_msg = error.get('error_description', error.get('error', response.text))
                except:
                    error_msg = response.text
                
                self.log(f"Token acquisition failed (HTTP {response.status_code}): {error_msg}", "ERROR")
                raise Exception(f"Failed to acquire token: {error_msg}")
        
        except requests.exceptions.RequestException as e:
            self.log(f"Network error during token acquisition: {e}", "ERROR")
            raise
        except Exception as e:
            self.log(f"Token acquisition error: {e}", "ERROR")
            raise
    
    def start_token_refresh_timer(self):
        """Start background token refresh timer (every 55 minutes)."""
        if not self.running:
            return
        
        self.log("Token refresh scheduled in 55 minutes", "TOKEN")
        self.token_refresh_timer = threading.Timer(55 * 60, self.refresh_token_callback)
        self.token_refresh_timer.daemon = True
        self.token_refresh_timer.start()
    
    def refresh_token_callback(self):
        """Background callback to refresh token."""
        if not self.running:
            return
        
        try:
            self.log("Auto-refreshing access token...", "TOKEN")
            self.acquire_token()
        except Exception as e:
            self.log(f"Token refresh failed: {e}", "ERROR")
        finally:
            # Schedule next refresh
            if self.running:
                self.start_token_refresh_timer()
    
    def get_graph_headers(self):
        """Get headers for Graph API requests."""
        return {
            'Authorization': f'Bearer {self.access_token}',
            'Content-Type': 'application/json'
        }
    
    def get_api_headers(self):
        """Get headers for API requests."""
        return {
            'X-API-Key': self.API_KEY,
            'Content-Type': 'application/json'
        }
    
    # ========================================================================
    # EMAIL OPERATIONS
    # ========================================================================
    
    def fetch_unread_emails(self):
        """Fetch unread emails from Microsoft Graph API."""
        self.log("Fetching unread emails...", "EMAIL")
        
        url = f"{self.GRAPH_API}/users/{self.MAILBOX_EMAIL}/mailFolders/{self.MAILBOX_FOLDER}/messages"
        params = {
            '$filter': 'isRead eq false',
            '$select': 'id,subject,from,toRecipients,receivedDateTime,body,hasAttachments',
            '$top': str(self.MAX_EMAILS_PER_FETCH),
            '$orderby': 'receivedDateTime desc'
        }
        
        try:
            response = requests.get(
                url,
                headers=self.get_graph_headers(),
                params=params,
                timeout=60
            )
            
            if response.status_code == 401:
                self.log("Token expired, refreshing...", "WARNING")
                self.acquire_token()
                # Retry with new token
                response = requests.get(
                    url,
                    headers=self.get_graph_headers(),
                    params=params,
                    timeout=60
                )
            
            if response.status_code == 200:
                emails = response.json().get('value', [])
                self.log(f"Found {len(emails)} unread emails", "EMAIL")
                return emails
            else:
                self.log(f"Failed to fetch emails: {response.status_code}", "ERROR")
                return []
        
        except Exception as e:
            self.log(f"Email fetch error: {e}", "ERROR")
            return []
    
    def get_attachments(self, email_id: str):
        """Get attachments for a specific email."""
        url = f"{self.GRAPH_API}/users/{self.MAILBOX_EMAIL}/messages/{email_id}/attachments"
        
        try:
            response = requests.get(
                url,
                headers=self.get_graph_headers(),
                timeout=60
            )
            
            if response.status_code == 200:
                return response.json().get('value', [])
            else:
                self.log(f"Failed to get attachments: {response.status_code}", "ERROR")
                return []
        
        except Exception as e:
            self.log(f"Get attachments error: {e}", "ERROR")
            return []
    
    def mark_as_read(self, email_id: str):
        """Mark email as read."""
        url = f"{self.GRAPH_API}/users/{self.MAILBOX_EMAIL}/messages/{email_id}"
        
        try:
            response = requests.patch(
                url,
                headers=self.get_graph_headers(),
                json={'isRead': True},
                timeout=30
            )
            
            return response.status_code == 200
        
        except Exception as e:
            self.log(f"Mark as read error: {e}", "ERROR")
            return False
    
    def save_attachment_file(self, filename: str, content_bytes: bytes):
        """Save attachment file to disk."""
        # Create date-based directory structure
        now = datetime.now(timezone.utc)
        relative_dir = f"{now.year}/{now.month:02d}"
        full_dir = Path(self.ATTACHMENT_PATH) / relative_dir
        full_dir.mkdir(parents=True, exist_ok=True)
        
        # Sanitize filename
        safe_filename = filename.replace('/', '_').replace('\\', '_')
        
        # Generate unique filename if exists
        file_path = full_dir / safe_filename
        counter = 1
        while file_path.exists():
            name, ext = os.path.splitext(safe_filename)
            file_path = full_dir / f"{name}_{counter}{ext}"
            counter += 1
        
        # Save file
        with open(file_path, 'wb') as f:
            f.write(content_bytes)
        
        relative_path = f"{relative_dir}/{file_path.name}"
        return relative_path
    
    def insert_attachment_to_db(self, attachment_data: dict):
        """Insert attachment into database via API."""
        # For testing, we'll use the API endpoint to insert
        # In production, you might want direct DB access
        
        # This is a simplified version - you may need to create a custom endpoint
        # For now, we'll just log it
        self.log(f"Attachment saved: {attachment_data['file_name']}", "SUCCESS")
        return True
    
    def process_emails(self):
        """Process all unread emails."""
        stats = {
            'emails_processed': 0,
            'attachments_saved': 0,
            'errors': 0
        }
        
        emails = self.fetch_unread_emails()
        
        for email in emails:
            try:
                email_id = email['id']
                subject = email.get('subject', 'No Subject')
                sender = email.get('from', {}).get('emailAddress', {}).get('address', 'unknown')
                received_at = email.get('receivedDateTime', '')
                
                self.log(f"Processing: {subject[:50]}...", "EMAIL")
                
                # Skip if no attachments
                if not email.get('hasAttachments', False):
                    self.mark_as_read(email_id)
                    stats['emails_processed'] += 1
                    continue
                
                # Process attachments
                attachments = self.get_attachments(email_id)
                
                for att in attachments:
                    # Skip non-file attachments
                    if att.get('@odata.type') != '#microsoft.graph.fileAttachment':
                        continue
                    
                    filename = att.get('name', 'unknown')
                    content_bytes = base64.b64decode(att.get('contentBytes', ''))
                    
                    # Save file
                    relative_path = self.save_attachment_file(filename, content_bytes)
                    
                    # Generate attachment ID
                    timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
                    hash_input = f"{email_id}_{filename}_{timestamp}"
                    hash_suffix = hashlib.md5(hash_input.encode()).hexdigest()[:6]
                    attachment_id = f"att_{timestamp}_{hash_suffix}"
                    
                    # Prepare attachment data
                    attachment_data = {
                        'attachment_id': attachment_id,
                        'email_id': email_id,
                        'file_name': filename,
                        'relative_path': relative_path,
                        'sender': sender,
                        'received_at': received_at
                    }
                    
                    # Save to database (via API or direct)
                    if self.insert_attachment_to_db(attachment_data):
                        stats['attachments_saved'] += 1
                
                # Mark email as read
                self.mark_as_read(email_id)
                stats['emails_processed'] += 1
                self.total_emails_processed += 1
            
            except Exception as e:
                self.log(f"Error processing email: {e}", "ERROR")
                stats['errors'] += 1
        
        if stats['emails_processed'] > 0:
            self.log(
                f"Processed {stats['emails_processed']} emails, "
                f"saved {stats['attachments_saved']} attachments",
                "SUCCESS"
            )
        else:
            self.log("No new emails found", "INFO")
        
        return stats
    
    # ========================================================================
    # API OPERATIONS
    # ========================================================================
    
    def check_health(self):
        """Check API server health."""
        try:
            response = requests.get(
                f"{self.API_BASE_URL}/api/v1/audit/health",
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                status = data.get('status', 'unknown')
                db_status = data.get('database', 'unknown')
                self.log(f"Health: {status} | Database: {db_status}", "HEALTH")
                return status == "healthy"
            else:
                self.log(f"Health check failed: {response.status_code}", "ERROR")
                return False
        
        except Exception as e:
            self.log(f"Health check error: {e}", "ERROR")
            return False
    
    def get_next_attachment(self):
        """Get next pending attachment from API."""
        try:
            response = requests.get(
                f"{self.API_BASE_URL}/api/v1/attachments/next",
                headers=self.get_api_headers(),
                timeout=10
            )
            
            if response.status_code == 204:
                return None
            elif response.status_code == 200:
                data = response.json()
                if isinstance(data, dict):
                    return data.get('attachment')
                return None
            else:
                self.log(f"Failed to get attachment: {response.status_code}", "ERROR")
                return None
        
        except Exception as e:
            self.log(f"Get attachment error: {e}", "ERROR")
            return None
    
    def forward_to_agent(self, attachment_id: str, file_name: str):
        """Forward attachment to agent by creating a job."""
        try:
            payload = {
                "attachment_id": attachment_id,
                "agent_name": "email_processor_agent",
                "requested_by": "standalone_processor"
            }
            
            response = requests.post(
                f"{self.API_BASE_URL}/api/v1/agent-jobs",
                headers=self.get_api_headers(),
                json=payload,
                timeout=10
            )
            
            if response.status_code == 201:
                data = response.json()
                if isinstance(data, dict):
                    job_id = data.get('job', {}).get('agent_job_id')
                    self.log(
                        f"Forwarded to agent: {file_name} (Job: {job_id})",
                        "AGENT"
                    )
                    self.total_attachments_forwarded += 1
                    return True
            else:
                self.log(f"Failed to forward: {response.status_code}", "ERROR")
                return False
        
        except Exception as e:
            self.log(f"Forward error: {e}", "ERROR")
            return False
    
    def get_stats(self):
        """Get system statistics."""
        try:
            response = requests.get(
                f"{self.API_BASE_URL}/api/v1/audit/stats",
                headers=self.get_api_headers(),
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            return None
        
        except Exception as e:
            self.log(f"Stats error: {e}", "ERROR")
            return None
    
    def process_pending_attachments(self):
        """Process all pending attachments and forward to agent."""
        processed_count = 0
        
        while True:
            attachment = self.get_next_attachment()
            
            if not attachment:
                break
            
            attachment_id = attachment.get('attachment_id')
            file_name = attachment.get('file_name')
            sender = attachment.get('sender')
            
            self.log(f"Found attachment: {file_name} from {sender}", "EMAIL")
            
            # Forward to agent
            if self.forward_to_agent(attachment_id, file_name):
                processed_count += 1
            
            # Small delay to avoid overwhelming the system
            time.sleep(0.5)
        
        if processed_count > 0:
            self.log(f"Forwarded {processed_count} attachments to agent", "SUCCESS")
    
    # ========================================================================
    # MAIN PROCESSING LOOP
    # ========================================================================
    
    def run_cycle(self):
        """Run one complete processing cycle."""
        self.cycle_count += 1
        
        print("\n" + "=" * 80)
        self.log(f"PROCESSING CYCLE #{self.cycle_count}", "INFO")
        print("-" * 80)
        
        # 1. Health check
        if not self.check_health():
            self.log("Server not healthy, skipping this cycle", "WARNING")
            print("-" * 80)
            return
        
        # 2. Fetch new emails
        self.process_emails()
        
        # 3. Process pending attachments and forward to agent
        self.process_pending_attachments()
        
        # 4. Show statistics
        stats_data = self.get_stats()
        if stats_data:
            attachments = stats_data.get('attachments', {})
            jobs = stats_data.get('jobs', {})
            self.log(
                f"System Stats - Pending: {attachments.get('pending')}, "
                f"Processed: {attachments.get('processed')}, "
                f"Jobs: {jobs.get('total')}",
                "INFO"
            )
        
        print("-" * 80)
        self.log(
            f"Cycle #{self.cycle_count} complete | "
            f"Total Emails: {self.total_emails_processed} | "
            f"Total Forwarded: {self.total_attachments_forwarded}",
            "SUCCESS"
        )
        print("=" * 80)
    
    def stop(self):
        """Stop the processor."""
        self.running = False
        if self.token_refresh_timer:
            self.token_refresh_timer.cancel()


def main():
    """Main function."""
    print("=" * 80)
    print("STANDALONE AUTOMATED EMAIL PROCESSOR")
    print("=" * 80)
    print(f"API Server: {StandaloneEmailProcessor.API_BASE_URL}")
    print(f"Mailbox: {StandaloneEmailProcessor.MAILBOX_EMAIL}")
    print(f"Check Interval: 60 seconds")
    print(f"Token Refresh: Every 55 minutes")
    print(f"Press Ctrl+C to stop")
    print(f"Uses ONLY requests library")
    print("=" * 80)
    
    # Validate configuration
    if not StandaloneEmailProcessor.MAILBOX_EMAIL:
        print("\nERROR: MAILBOX_EMAIL not configured!")
        print("Please set environment variable or edit the script directly.")
        print("\nExample:")
        print("  export MAILBOX_EMAIL=your-email@company.com")
        print("  export AZURE_TENANT_ID=your-tenant-id")
        print("  export AZURE_CLIENT_ID=your-client-id")
        print("  export AZURE_CLIENT_SECRET=your-client-secret")
        print("  export API_KEY=your-api-key")
        sys.exit(1)
    
    try:
        processor = StandaloneEmailProcessor()
    except Exception as e:
        print(f"\nERROR: Failed to initialize processor: {e}")
        print("\nPlease check your configuration and try again.")
        sys.exit(1)
    
    try:
        while processor.running:
            processor.run_cycle()
            
            # Wait 60 seconds before next cycle
            print(f"\nWaiting 10 seconds before next cycle...\n")
            time.sleep(10)
    
    except KeyboardInterrupt:
        print("\n" + "=" * 80)
        print(f"Stopping processor...")
        processor.stop()
        print(f"Processor stopped after {processor.cycle_count} cycles")
        print(f"Total emails processed: {processor.total_emails_processed}")
        print(f"Total attachments forwarded: {processor.total_attachments_forwarded}")
        print("=" * 80)
    except Exception as e:
        print(f"\nERROR: Unexpected error: {e}")
        processor.stop()
        sys.exit(1)


if __name__ == "__main__":
    main()

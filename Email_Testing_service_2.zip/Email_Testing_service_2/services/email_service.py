"""
Email Service
Fetches emails and processes attachments via Microsoft Graph API.
"""
import base64
import hashlib
from datetime import datetime, timezone
from typing import List, Dict, Any
import httpx
import logging

from core.config import settings
from core.auth import token_manager
from core.database import db
from services.file_service import file_service

logger = logging.getLogger(__name__)


class EmailService:
    """Handles email operations via Microsoft Graph API."""
    
    GRAPH_API = "https://graph.microsoft.com/v1.0"
    
    def __init__(self):
        self.mailbox = settings.MAILBOX_EMAIL
        self.folder = settings.MAILBOX_FOLDER
        self.max_emails = settings.MAX_EMAILS_PER_FETCH
    
    def _get_headers(self) -> Dict[str, str]:
        """Get authorization headers for Graph API."""
        token = token_manager.get_access_token()
        return {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
    
    def _generate_attachment_id(self, email_id: str, filename: str) -> str:
        """Generate unique attachment ID."""
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        hash_input = f"{email_id}_{filename}_{timestamp}"
        hash_suffix = hashlib.md5(hash_input.encode()).hexdigest()[:6]
        return f"att_{timestamp}_{hash_suffix}"
    
    def _convert_datetime_for_mysql(self, iso_datetime: str) -> str:
        """Convert ISO 8601 datetime to MySQL compatible format."""
        if not iso_datetime:
            return None
        
        # Parse ISO 8601 format (e.g., '2025-12-14T07:44:28Z')
        try:
            dt = datetime.fromisoformat(iso_datetime.replace('Z', '+00:00'))
            # Return in MySQL datetime format
            return dt.strftime('%Y-%m-%d %H:%M:%S')
        except Exception as e:
            logger.warning(f"Failed to parse datetime '{iso_datetime}': {e}")
            return None

    
    def fetch_unread_emails(self) -> List[Dict[str, Any]]:
        """Fetch unread emails from mailbox."""
        logger.info(f"Fetching unread emails from {self.mailbox}")
        
        url = f"{self.GRAPH_API}/users/{self.mailbox}/mailFolders/{self.folder}/messages"
        params = {
            '$filter': 'isRead eq false',
            '$select': 'id,subject,from,toRecipients,receivedDateTime,body,hasAttachments',
            '$top': str(self.max_emails),
            '$orderby': 'receivedDateTime desc'
        }
        
        response = httpx.get(url, headers=self._get_headers(), params=params, timeout=60)
        
        if response.status_code == 401:
            raise Exception("Authentication failed - token may be expired")
        
        if response.status_code != 200:
            raise Exception(f"Failed to fetch emails: {response.status_code}")
        
        emails = response.json().get('value', [])
        logger.info(f"Found {len(emails)} unread emails")
        
        return emails
    
    def get_attachments(self, email_id: str) -> List[Dict[str, Any]]:
        """Get attachments for a specific email."""
        url = f"{self.GRAPH_API}/users/{self.mailbox}/messages/{email_id}/attachments"
        
        response = httpx.get(url, headers=self._get_headers(), timeout=60)
        
        if response.status_code != 200:
            logger.error(f"Failed to get attachments: {response.status_code}")
            return []
        
        return response.json().get('value', [])
    
    def mark_as_read(self, email_id: str) -> bool:
        """Mark email as read."""
        url = f"{self.GRAPH_API}/users/{self.mailbox}/messages/{email_id}"
        
        response = httpx.patch(
            url,
            headers=self._get_headers(),
            json={'isRead': True},
            timeout=30
        )
        
        if response.status_code == 200:
            logger.info(f"Marked email as read: {email_id[:20]}...")
            return True
        else:
            logger.warning(f"Failed to mark email as read: {response.status_code}")
            return False
    
    def process_emails(self) -> Dict[str, int]:
        """
        Process all unread emails: fetch attachments and store them.
        
        Returns:
            Statistics dict
        """
        stats = {
            'emails_processed': 0,
            'attachments_saved': 0,
            'errors': 0
        }
        
        try:
            emails = self.fetch_unread_emails()
        except Exception as e:
            logger.error(f"Failed to fetch emails: {e}")
            stats['errors'] = 1
            return stats
        
        for email in emails:
            try:
                email_id = email['id']
                subject = email.get('subject', 'No Subject')
                sender = email.get('from', {}).get('emailAddress', {}).get('address', 'unknown')
                received_at = email.get('receivedDateTime', '')
                body = email.get('body', {}).get('content', '')
                
                # Get recipients
                recipients = email.get('toRecipients', [])
                recipient = recipients[0]['emailAddress']['address'] if recipients else self.mailbox
                
                logger.info(f"Processing email: {subject[:50]}...")
                
                # Skip if no attachments
                if not email.get('hasAttachments', False):
                    self.mark_as_read(email_id)
                    stats['emails_processed'] += 1
                    continue
                
                # Process attachments
                attachments = self.get_attachments(email_id)
                
                for att in attachments:
                    # Skip non-file attachments
                    if att.get('@odata.type') != '#microsoft.graph.fileAttachment':
                        continue
                    
                    filename = att.get('name', 'unknown')
                    content_bytes = base64.b64decode(att.get('contentBytes', ''))
                    
                    # Generate unique ID
                    attachment_id = self._generate_attachment_id(email_id, filename)
                    
                    # Check if already exists
                    if db.attachment_exists(attachment_id):
                        logger.info(f"Attachment already exists: {attachment_id}")
                        continue
                    
                    # Save file
                    relative_path, _ = file_service.save_file(filename, content_bytes)
                    
                    # Store in database
                    attachment_data = {
                        'attachment_id': attachment_id,
                        'email_id': email_id,
                        'file_name': filename,
                        'relative_path': relative_path,
                        'sender': sender,
                        'recipient': recipient,
                        'email_timestamp': self._convert_datetime_for_mysql(received_at),
                        'body': body[:5000] if body else None,
                        'is_read': 1,
                        'send_to_agent': 0,
                        'status': 'ready'
                    }
                    
                    if db.insert_attachment(attachment_data):
                        logger.info(f"Stored attachment: {attachment_id} - {filename}")
                        stats['attachments_saved'] += 1
                
                # Mark email as read
                self.mark_as_read(email_id)
                stats['emails_processed'] += 1
                
            except Exception as e:
                logger.error(f"Error processing email: {e}")
                stats['errors'] += 1
        
        logger.info(
            f"Processing complete: {stats['emails_processed']} emails, "
            f"{stats['attachments_saved']} attachments, {stats['errors']} errors"
        )
        
        return stats


# Global email service instance
email_service = EmailService()

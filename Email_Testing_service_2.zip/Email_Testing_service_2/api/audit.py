"""
Audit and Monitoring Endpoints
System statistics, health checks, token status.
"""
from fastapi import APIRouter, Header, HTTPException
from datetime import datetime, timezone
import uuid

from core.database import db
from core.auth import token_manager
from core.config import settings

router = APIRouter(prefix="/audit", tags=["Audit"])


def verify_api_key(x_api_key: str = Header(...)):
    """Verify API key."""
    if x_api_key != settings.API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return x_api_key


def get_timestamp() -> str:
    """Get current UTC timestamp."""
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def build_meta(request_id: str) -> dict:
    """Build standard metadata."""
    return {
        "request_id": request_id,
        "api_version": "v1",
        "generated_at": get_timestamp()
    }


@router.get("/health")
async def health_check():
    """
    Health check endpoint (no authentication required).
    Quick check of system status.
    """
    db_healthy = db.health_check()
    
    return {
        "status": "healthy" if db_healthy else "unhealthy",
        "timestamp": get_timestamp(),
        "database": "connected" if db_healthy else "disconnected",
        "version": settings.APP_VERSION
    }


@router.get("/stats")
async def get_system_stats(
    x_api_key: str = Header(..., alias="X-API-Key")
):
    """
    Get comprehensive system statistics.
    
    Includes:
    - Attachment statistics (total, pending, processed, errors)
    - Job statistics (total, queued, running, completed, failed)
    - System information (database, token, mailbox, version)
    """
    verify_api_key(x_api_key)
    request_id = str(uuid.uuid4())
    
    # Get statistics
    attachment_stats = db.get_attachment_stats()
    job_stats = db.get_job_stats()
    token_info = token_manager.get_token_info()
    db_healthy = db.health_check()
    
    return {
        "meta": build_meta(request_id),
        "attachments": attachment_stats,
        "jobs": job_stats,
        "system": {
            "database": "healthy" if db_healthy else "unhealthy",
            "token": token_info,
            "mailbox": settings.MAILBOX_EMAIL,
            "version": settings.APP_VERSION
        }
    }


@router.get("/token")
async def get_token_status(
    x_api_key: str = Header(..., alias="X-API-Key")
):
    """Get token status and expiration information."""
    verify_api_key(x_api_key)
    request_id = str(uuid.uuid4())
    
    token_info = token_manager.get_token_info()
    
    if not token_info:
        return {
            "meta": build_meta(request_id),
            "token": {
                "status": "not_acquired",
                "message": "No token available. Run auth_setup.py to acquire token."
            }
        }
    
    return {
        "meta": build_meta(request_id),
        "token": {
            "status": "valid" if token_info['is_valid'] else "expired",
            "expires_at": token_info['expires_at'],
            "acquired_at": token_info['acquired_at'],
            "token_type": token_info['token_type']
        }
    }


@router.post("/refresh-token")
async def force_refresh_token(
    x_api_key: str = Header(..., alias="X-API-Key")
):
    """Force refresh the access token."""
    verify_api_key(x_api_key)
    request_id = str(uuid.uuid4())
    
    try:
        token_data = token_manager.refresh_token()
        
        return {
            "meta": build_meta(request_id),
            "message": "Token refreshed successfully",
            "token": {
                "expires_at": token_data['expires_at_iso'],
                "expires_in": token_data['expires_in']
            }
        }
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={
                "meta": build_meta(request_id),
                "error": {
                    "code": "TOKEN_REFRESH_FAILED",
                    "message": str(e)
                }
            }
        )

"""API endpoints for email attachment processor."""
from api.attachments import router as attachments_router
from api.jobs import router as jobs_router
from api.audit import router as audit_router

__all__ = ['attachments_router', 'jobs_router', 'audit_router']

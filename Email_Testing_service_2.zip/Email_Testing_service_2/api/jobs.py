"""
Agent Job Endpoints
MUST HAVE: POST /api/v1/agent-jobs
"""
from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel, Field
from datetime import datetime, timezone
from typing import Optional
import uuid
import hashlib

from core.database import db
from core.config import settings

router = APIRouter(prefix="/agent-jobs", tags=["Agent Jobs"])


def verify_api_key(x_api_key: str = Header(...)):
    """Verify API key."""
    if x_api_key != settings.API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return x_api_key


def get_timestamp() -> str:
    """Get current UTC timestamp."""
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def build_meta(request_id: str) -> dict:
    """Build standard metadata."""
    return {
        "request_id": request_id,
        "api_version": "v1",
        "generated_at": get_timestamp()
    }


# Request/Response Models
class CreateJobRequest(BaseModel):
    """Request body for creating agent job."""
    attachment_id: str = Field(..., description="Attachment ID to process")
    agent_name: str = Field(..., description="Name of the AI agent")
    requested_by: str = Field(..., description="Who requested this job")


class UpdateJobRequest(BaseModel):
    """Request body for updating job status."""
    status: str = Field(..., description="New status: running, completed, failed")
    result: Optional[str] = Field(None, description="Job result (if completed)")
    error_message: Optional[str] = Field(None, description="Error message (if failed)")


def generate_job_id(attachment_id: str, agent_name: str) -> str:
    """Generate unique job ID."""
    timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
    hash_input = f"{attachment_id}_{agent_name}_{timestamp}"
    hash_suffix = hashlib.md5(hash_input.encode()).hexdigest()[:6]
    return f"job_{timestamp}_{hash_suffix}"


@router.post("", status_code=201)
async def create_agent_job(
    request: CreateJobRequest,
    x_api_key: str = Header(..., alias="X-API-Key")
):
    """
    **MUST HAVE ENDPOINT**
    
    Create a new agent job to process an attachment.
    
    This endpoint:
    1. Validates the attachment exists
    2. Creates a job record
    3. Marks the attachment as sent to agent (send_to_agent=1)
    4. Returns job details
    """
    verify_api_key(x_api_key)
    request_id = str(uuid.uuid4())
    
    # Validate attachment exists
    attachment = db.get_attachment_by_id(request.attachment_id)
    if not attachment:
        raise HTTPException(
            status_code=404,
            detail={
                "meta": build_meta(request_id),
                "error": {
                    "code": "ATTACHMENT_NOT_FOUND",
                    "message": f"Attachment {request.attachment_id} not found"
                }
            }
        )
    
    # Generate job ID
    job_id = generate_job_id(request.attachment_id, request.agent_name)
    
    # Create job
    job_data = {
        'agent_job_id': job_id,
        'attachment_id': request.attachment_id,
        'agent_name': request.agent_name,
        'requested_by': request.requested_by,
        'status': 'queued'
    }
    
    if not db.create_job(job_data):
        raise HTTPException(
            status_code=500,
            detail={
                "meta": build_meta(request_id),
                "error": {
                    "code": "JOB_CREATION_FAILED",
                    "message": "Failed to create job"
                }
            }
        )
    
    # Mark attachment as sent to agent
    db.update_attachment_agent_status(request.attachment_id, send_to_agent=True)
    
    # Return job details
    return {
        "meta": build_meta(request_id),
        "job": {
            "agent_job_id": job_id,
            "attachment_id": request.attachment_id,
            "file_name": attachment['file_name'],
            "relative_path": attachment['relative_path'],
            "send_to_agent": True,
            "agent_name": request.agent_name,
            "status": "queued"
        }
    }


@router.get("")
async def list_jobs(
    x_api_key: str = Header(..., alias="X-API-Key")
):
    """List all agent jobs."""
    verify_api_key(x_api_key)
    request_id = str(uuid.uuid4())
    
    jobs = db.get_recent_jobs(limit=50)
    
    return {
        "meta": build_meta(request_id),
        "total_count": len(jobs),
        "jobs": [
            {
                "agent_job_id": job['agent_job_id'],
                "attachment_id": job['attachment_id'],
                "file_name": job.get('file_name'),
                "agent_name": job['agent_name'],
                "status": job['status'],
                "created_at": job['created_at'].isoformat() if job['created_at'] else None
            }
            for job in jobs
        ]
    }


@router.get("/{job_id}")
async def get_job(
    job_id: str,
    x_api_key: str = Header(..., alias="X-API-Key")
):
    """Get specific job by ID."""
    verify_api_key(x_api_key)
    request_id = str(uuid.uuid4())
    
    job = db.get_job_by_id(job_id)
    
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    return {
        "meta": build_meta(request_id),
        "job": {
            "agent_job_id": job['agent_job_id'],
            "attachment_id": job['attachment_id'],
            "agent_name": job['agent_name'],
            "requested_by": job['requested_by'],
            "status": job['status'],
            "result": job.get('result'),
            "error_message": job.get('error_message'),
            "created_at": job['created_at'].isoformat() if job['created_at'] else None,
            "updated_at": job['updated_at'].isoformat() if job['updated_at'] else None
        }
    }


@router.patch("/{job_id}")
async def update_job(
    job_id: str,
    request: UpdateJobRequest,
    x_api_key: str = Header(..., alias="X-API-Key")
):
    """Update job status (running, completed, failed)."""
    verify_api_key(x_api_key)
    request_id = str(uuid.uuid4())
    
    # Validate job exists
    job = db.get_job_by_id(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    # Validate status
    valid_statuses = ['running', 'completed', 'failed']
    if request.status not in valid_statuses:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid status. Must be one of: {', '.join(valid_statuses)}"
        )
    
    # Update job
    if not db.update_job_status(job_id, request.status, request.result, request.error_message):
        raise HTTPException(status_code=500, detail="Failed to update job")
    
    return {
        "meta": build_meta(request_id),
        "message": "Job updated successfully",
        "job_id": job_id,
        "status": request.status
    }

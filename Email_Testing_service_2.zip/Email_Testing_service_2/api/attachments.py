"""
Attachment Endpoints
MUST HAVE: GET /api/v1/attachments/next
"""
from fastapi import APIRouter, Header, HTTPException, Query, Response
from datetime import datetime, timezone
from typing import Optional
import uuid

from core.database import db
from core.config import settings

router = APIRouter(prefix="/attachments", tags=["Attachments"])


def verify_api_key(x_api_key: str = Header(...)):
    """Verify API key."""
    if x_api_key != settings.API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return x_api_key


def get_timestamp() -> str:
    """Get current UTC timestamp."""
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def build_meta(request_id: str) -> dict:
    """Build standard metadata."""
    return {
        "request_id": request_id,
        "api_version": "v1",
        "generated_at": get_timestamp()
    }


@router.get("/next")
async def get_next_attachment(
    newest_first: bool = Query(False, description="Return newest first (default: oldest first)"),
    x_api_key: str = Header(..., alias="X-API-Key")
):
    """
    **MUST HAVE ENDPOINT**
    
    Get the next attachment ready for processing.
    
    - **newest_first**: If true, returns newest attachment. Default: false (FIFO - oldest first)
    - Returns 204 if no attachments available
    - Returns 200 with attachment details if available
    """
    verify_api_key(x_api_key)
    request_id = str(uuid.uuid4())
    
    # Get next attachment
    attachment = db.get_next_attachment(newest_first=newest_first)
    
    if not attachment:
        # No attachment available - return 204 No Content
        return Response(status_code=204)
    
    # Build response
    response = {
        "meta": build_meta(request_id),
        "attachment": {
            "attachment_id": attachment['attachment_id'],
            "email_id": attachment['email_id'],
            "file_name": attachment['file_name'],
            "relative_path": attachment['relative_path'],
            "email_timestamp": attachment['email_timestamp'].isoformat() if attachment['email_timestamp'] else None,
            "sender": attachment['sender'],
            "recipient": attachment['recipient'],
            "flags": {
                "is_read": bool(attachment['is_read']),
                "send_to_agent": bool(attachment['send_to_agent'])
            },
            "status": attachment['status']
        }
    }
    
    return response


@router.get("/pending")
async def get_pending_attachments(
    x_api_key: str = Header(..., alias="X-API-Key")
):
    """Get all pending attachments (not yet sent to agent)."""
    verify_api_key(x_api_key)
    request_id = str(uuid.uuid4())
    
    attachments = db.get_pending_attachments()
    
    return {
        "meta": build_meta(request_id),
        "total_count": len(attachments),
        "attachments": [
            {
                "attachment_id": att['attachment_id'],
                "file_name": att['file_name'],
                "sender": att['sender'],
                "email_timestamp": att['email_timestamp'].isoformat() if att['email_timestamp'] else None,
                "status": att['status']
            }
            for att in attachments
        ]
    }


@router.get("/processed")
async def get_processed_attachments(
    x_api_key: str = Header(..., alias="X-API-Key")
):
    """Get processed attachments (sent to agent)."""
    verify_api_key(x_api_key)
    request_id = str(uuid.uuid4())
    
    attachments = db.get_processed_attachments(limit=50)
    
    return {
        "meta": build_meta(request_id),
        "total_count": len(attachments),
        "attachments": [
            {
                "attachment_id": att['attachment_id'],
                "file_name": att['file_name'],
                "sender": att['sender'],
                "email_timestamp": att['email_timestamp'].isoformat() if att['email_timestamp'] else None,
                "status": att['status']
            }
            for att in attachments
        ]
    }


@router.get("/{attachment_id}")
async def get_attachment_by_id(
    attachment_id: str,
    x_api_key: str = Header(..., alias="X-API-Key")
):
    """Get specific attachment by ID."""
    verify_api_key(x_api_key)
    request_id = str(uuid.uuid4())
    
    attachment = db.get_attachment_by_id(attachment_id)
    
    if not attachment:
        raise HTTPException(status_code=404, detail="Attachment not found")
    
    return {
        "meta": build_meta(request_id),
        "attachment": {
            "attachment_id": attachment['attachment_id'],
            "email_id": attachment['email_id'],
            "file_name": attachment['file_name'],
            "relative_path": attachment['relative_path'],
            "email_timestamp": attachment['email_timestamp'].isoformat() if attachment['email_timestamp'] else None,
            "sender": attachment['sender'],
            "recipient": attachment['recipient'],
            "flags": {
                "is_read": bool(attachment['is_read']),
                "send_to_agent": bool(attachment['send_to_agent'])
            },
            "status": attachment['status']
        }
    }

"""
Email Attachment Processor - Organizational Version
FastAPI Application Entry Point

Features:
- Fetch emails from Microsoft Outlook via Graph API
- Store attachments with metadata in MySQL
- Provide REST API for attachment processing
- Support for AI agent job management

MUST-HAVE Endpoints:
- GET /api/v1/attachments/next - Get next attachment for processing
- POST /api/v1/agent-jobs - Create job to send attachment to agent
"""
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn

from core.config import settings
from api import attachments_router, jobs_router, audit_router

# Configure logging
logging.basicConfig(
    level=logging.INFO if settings.DEBUG else logging.WARNING,
    format='%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler."""
    logger.info("=" * 70)
    logger.info("Email Attachment Processor - Organizational Version")
    logger.info(f"Version: {settings.APP_VERSION}")
    logger.info(f"Mailbox: {settings.MAILBOX_EMAIL}")
    logger.info(f"Debug Mode: {settings.DEBUG}")
    logger.info("=" * 70)
    
    # Initialize database tables
    logger.info("Initializing database tables...")
    from core.database import db
    if db.create_tables():
        logger.info("✓ Database tables initialized successfully")
    else:
        logger.error("✗ Failed to initialize database tables")
    
    yield
    # Graceful shutdown
    logger.info("Application shutting down")
    from core.auth import token_manager
    token_manager.stop_auto_refresh()


# Create FastAPI application
app = FastAPI(
    title="Email Attachment Processor",
    description="API for processing email attachments from Microsoft Outlook (Organizational Version)",
    version=settings.APP_VERSION,
    lifespan=lifespan,
    docs_url="/docs" if settings.DEBUG else None,
    redoc_url="/redoc" if settings.DEBUG else None
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

# Mount routers
app.include_router(attachments_router, prefix="/api/v1")
app.include_router(jobs_router, prefix="/api/v1")
app.include_router(audit_router, prefix="/api/v1")


@app.get("/", tags=["Root"])
async def root():
    """Root endpoint with API information."""
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "type": "Organizational (Client Credentials Flow)",
        "docs": "/docs" if settings.DEBUG else "Disabled in production",
        "endpoints": {
            "must_have": {
                "get_next_attachment": "GET /api/v1/attachments/next",
                "create_agent_job": "POST /api/v1/agent-jobs"
            },
            "additional": {
                "pending_attachments": "GET /api/v1/attachments/pending",
                "processed_attachments": "GET /api/v1/attachments/processed",
                "list_jobs": "GET /api/v1/agent-jobs",
                "system_stats": "GET /api/v1/audit/stats",
                "health_check": "GET /api/v1/audit/health"
            }
        }
    }


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=5000,
        reload=settings.DEBUG
    )

"""
Configuration Module
Centralized configuration using environment variables.
"""
import os
from pathlib import Path
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    # Application
    APP_NAME: str = "Email Attachment Processor - Organizational"
    APP_VERSION: str = "2.0.0"
    DEBUG: bool = False
    API_KEY: str
    
    # Database (PostgreSQL)
    DB_HOST: str = "localhost"
    DB_PORT: int = 5432
    DB_USER: str = "postgres"
    DB_PASSWORD: str
    DB_NAME: str = "email_attachments"
    
    # Azure AD (Client Credentials Flow)
    AZURE_TENANT_ID: str
    AZURE_CLIENT_ID: str
    AZURE_CLIENT_SECRET: str
    
    # Email Configuration
    MAILBOX_EMAIL: str
    MAILBOX_FOLDER: str = "Inbox"
    MAX_EMAILS_PER_FETCH: int = 50
    
    # Storage
    ATTACHMENT_PATH: str = "attachments"
    TOKEN_FILE: str = "config/token.json"
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


# Global settings instance
settings = Settings()

# Ensure directories exist
Path(settings.ATTACHMENT_PATH).mkdir(parents=True, exist_ok=True)
Path(settings.TOKEN_FILE).parent.mkdir(parents=True, exist_ok=True)

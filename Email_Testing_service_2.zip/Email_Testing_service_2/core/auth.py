"""
Authentication Module
Manages Microsoft Graph API tokens using Client Credentials Flow.
"""
import json
import time
import threading
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional, Dict, Any
import httpx
import logging

from core.config import settings

logger = logging.getLogger(__name__)


class TokenManager:
    """
    Manages access tokens for Microsoft Graph API (Client Credentials Flow).
    Features: Auto-refresh, thread-safe, persistent storage.
    """
    
    TOKEN_ENDPOINT = "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"
    REFRESH_BUFFER = 300  # Refresh 5 minutes before expiry
    AUTO_REFRESH_INTERVAL = 3300  # 55 minutes in seconds
    
    def __init__(self):
        self.token_file = Path(settings.TOKEN_FILE)
        self.token_file.parent.mkdir(parents=True, exist_ok=True)
        
        self._token_data: Optional[Dict[str, Any]] = None
        self._lock = threading.Lock()
        self._refresh_timer: Optional[threading.Timer] = None
        self._shutdown = False
        
        # Load existing token
        self._load_token()
        
        # Start background auto-refresh
        self._start_auto_refresh()
    
    def _load_token(self) -> None:
        """Load token from file."""
        if self.token_file.exists():
            try:
                with open(self.token_file, 'r') as f:
                    self._token_data = json.load(f)
                logger.info("Token loaded from file")
            except Exception as e:
                logger.warning(f"Failed to load token: {e}")
                self._token_data = None
    
    def _save_token(self) -> None:
        """Save token to file."""
        if self._token_data:
            try:
                with open(self.token_file, 'w') as f:
                    json.dump(self._token_data, f, indent=2)
                logger.info("Token saved to file")
            except Exception as e:
                logger.error(f"Failed to save token: {e}")
    
    def _is_token_valid(self) -> bool:
        """Check if token is valid and not expiring soon."""
        if not self._token_data:
            return False
        
        expires_at = self._token_data.get('expires_at')
        if not expires_at:
            return False
        
        return expires_at > (time.time() + self.REFRESH_BUFFER)
    
    def _acquire_token(self) -> Dict[str, Any]:
        """Acquire new access token from Azure AD."""
        logger.info("Acquiring new access token")
        
        endpoint = self.TOKEN_ENDPOINT.format(tenant=settings.AZURE_TENANT_ID)
        
        data = {
            'grant_type': 'client_credentials',
            'client_id': settings.AZURE_CLIENT_ID,
            'client_secret': settings.AZURE_CLIENT_SECRET,
            'scope': 'https://graph.microsoft.com/.default'
        }
        
        response = httpx.post(
            endpoint,
            data=data,
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            timeout=30
        )
        
        if response.status_code != 200:
            error = response.json()
            error_msg = error.get('error_description', response.text)
            logger.error(f"Token acquisition failed: {error_msg}")
            raise Exception(f"Failed to acquire token: {error_msg}")
        
        token_response = response.json()
        expires_in = token_response.get('expires_in', 3600)
        expires_at = time.time() + expires_in
        
        self._token_data = {
            'access_token': token_response['access_token'],
            'token_type': token_response.get('token_type', 'Bearer'),
            'expires_in': expires_in,
            'expires_at': expires_at,
            'expires_at_iso': datetime.fromtimestamp(expires_at, tz=timezone.utc).isoformat(),
            'acquired_at': datetime.now(timezone.utc).isoformat()
        }
        
        self._save_token()
        logger.info(f"Token acquired, expires in {expires_in}s")
        
        return self._token_data
    
    def get_access_token(self) -> str:
        """Get valid access token (auto-refresh if needed)."""
        with self._lock:
            if not self._is_token_valid():
                self._acquire_token()
            
            if not self._token_data or 'access_token' not in self._token_data:
                raise Exception("No valid access token available")
            
            return self._token_data['access_token']
    
    def refresh_token(self) -> Dict[str, Any]:
        """Force token refresh."""
        with self._lock:
            return self._acquire_token()
    
    def _start_auto_refresh(self) -> None:
        """Start background auto-refresh timer."""
        if self._shutdown:
            return
        
        # Only start if we have a valid token
        if self._token_data and 'access_token' in self._token_data:
            logger.info(f"⏰ Background auto-refresh scheduled in {self.AUTO_REFRESH_INTERVAL / 60:.0f} minutes")
            self._refresh_timer = threading.Timer(self.AUTO_REFRESH_INTERVAL, self._auto_refresh_callback)
            self._refresh_timer.daemon = True  # Thread will not prevent shutdown
            self._refresh_timer.start()
    
    def _auto_refresh_callback(self) -> None:
        """Background callback to refresh token."""
        if self._shutdown:
            return
        
        try:
            logger.info("🔄 Background auto-refresh triggered")
            self.refresh_token()
            logger.info("✅ Background token refresh successful")
        except Exception as e:
            logger.error(f"❌ Background token refresh failed: {e}")
        finally:
            # Schedule next refresh
            if not self._shutdown:
                self._start_auto_refresh()
    
    def stop_auto_refresh(self) -> None:
        """Stop background auto-refresh (for graceful shutdown)."""
        logger.info("Stopping background auto-refresh")
        self._shutdown = True
        if self._refresh_timer:
            self._refresh_timer.cancel()
    
    def get_token_info(self) -> Optional[Dict[str, Any]]:
        """Get token metadata (without actual token)."""
        if not self._token_data:
            return None
        
        return {
            'expires_at': self._token_data.get('expires_at_iso'),
            'acquired_at': self._token_data.get('acquired_at'),
            'is_valid': self._is_token_valid(),
            'token_type': self._token_data.get('token_type')
        }


# Global token manager instance
token_manager = TokenManager()

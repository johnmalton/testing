"""
Database Module
Handles all PostgreSQL database operations.
"""
import psycopg2
from psycopg2.extras import RealDictCursor
from psycopg2 import sql
from contextlib import contextmanager
from typing import Optional, List, Dict, Any
import logging

from core.config import settings

logger = logging.getLogger(__name__)


class Database:
    """PostgreSQL database manager with connection pooling."""
    
    def __init__(self):
        self.config = {
            "host": settings.DB_HOST,
            "port": settings.DB_PORT,
            "user": settings.DB_USER,
            "password": settings.DB_PASSWORD,
            "database": settings.DB_NAME,
        }
    
    @contextmanager
    def connection(self):
        """Get database connection context manager."""
        conn = psycopg2.connect(**self.config)
        try:
            yield conn
        finally:
            conn.close()
    
    @contextmanager
    def cursor(self):
        """Get database cursor context manager."""
        with self.connection() as conn:
            cursor = conn.cursor(cursor_factory=RealDictCursor)
            try:
                yield cursor
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                cursor.close()
    
    def health_check(self) -> bool:
        """Check database connection health."""
        try:
            with self.cursor() as cur:
                cur.execute("SELECT 1")
                return True
        except Exception as e:
            logger.error(f"Database health check failed: {e}")
            return False
    
    def create_tables(self) -> bool:
        """Create tables if they don't exist."""
        try:
            with self.cursor() as cur:
                # Create attachments table
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS attachments (
                        id SERIAL PRIMARY KEY,
                        attachment_id VARCHAR(100) NOT NULL UNIQUE,
                        email_id VARCHAR(200) NOT NULL,
                        file_name VARCHAR(255) NOT NULL,
                        relative_path VARCHAR(500) NOT NULL,
                        sender VARCHAR(255),
                        recipient VARCHAR(255),
                        email_timestamp TIMESTAMP,
                        body TEXT,
                        is_read BOOLEAN DEFAULT FALSE,
                        send_to_agent BOOLEAN DEFAULT FALSE,
                        status VARCHAR(50) DEFAULT 'ready',
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                # Create indexes for attachments
                cur.execute("""
                    CREATE INDEX IF NOT EXISTS idx_status_timestamp 
                    ON attachments(status, email_timestamp)
                """)
                cur.execute("""
                    CREATE INDEX IF NOT EXISTS idx_send_to_agent 
                    ON attachments(send_to_agent)
                """)
                cur.execute("""
                    CREATE INDEX IF NOT EXISTS idx_email_id 
                    ON attachments(email_id)
                """)
                
                # Create agent_jobs table
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS agent_jobs (
                        id SERIAL PRIMARY KEY,
                        agent_job_id VARCHAR(100) NOT NULL UNIQUE,
                        attachment_id VARCHAR(100) NOT NULL,
                        agent_name VARCHAR(100) NOT NULL,
                        requested_by VARCHAR(100) NOT NULL,
                        status VARCHAR(50) DEFAULT 'queued',
                        result TEXT,
                        error_message TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                # Create indexes for agent_jobs
                cur.execute("""
                    CREATE INDEX IF NOT EXISTS idx_attachment_id 
                    ON agent_jobs(attachment_id)
                """)
                cur.execute("""
                    CREATE INDEX IF NOT EXISTS idx_status 
                    ON agent_jobs(status)
                """)
                
                logger.info("✓ Database tables created/verified successfully")
                return True
        except Exception as e:
            logger.error(f"Failed to create tables: {e}")
            return False
    
    # ========================================================================
    # ATTACHMENT OPERATIONS
    # ========================================================================
    
    def get_next_attachment(self, newest_first: bool = False) -> Optional[Dict[str, Any]]:
        """Get next attachment ready for processing (FIFO by default)."""
        order = "DESC" if newest_first else "ASC"
        query = f"""
            SELECT * FROM attachments
            WHERE status = 'ready' AND send_to_agent = FALSE
            ORDER BY email_timestamp {order}
            LIMIT 1
        """
        with self.cursor() as cur:
            cur.execute(query)
            return cur.fetchone()
    
    def get_attachment_by_id(self, attachment_id: str) -> Optional[Dict[str, Any]]:
        """Get attachment by ID."""
        query = "SELECT * FROM attachments WHERE attachment_id = %s"
        with self.cursor() as cur:
            cur.execute(query, (attachment_id,))
            return cur.fetchone()
    
    def get_pending_attachments(self) -> List[Dict[str, Any]]:
        """Get all pending attachments."""
        query = """
            SELECT attachment_id, email_id, file_name, sender, 
                   email_timestamp, status
            FROM attachments
            WHERE status = 'ready' AND send_to_agent = FALSE
            ORDER BY email_timestamp DESC
        """
        with self.cursor() as cur:
            cur.execute(query)
            return cur.fetchall()
    
    def get_processed_attachments(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get processed attachments."""
        query = """
            SELECT attachment_id, email_id, file_name, sender,
                   email_timestamp, status
            FROM attachments
            WHERE send_to_agent = TRUE
            ORDER BY email_timestamp DESC
            LIMIT %s
        """
        with self.cursor() as cur:
            cur.execute(query, (limit,))
            return cur.fetchall()
    
    def insert_attachment(self, data: Dict[str, Any]) -> bool:
        """Insert new attachment."""
        query = """
            INSERT INTO attachments (
                attachment_id, email_id, file_name, relative_path,
                sender, recipient, email_timestamp, body,
                is_read, send_to_agent, status
            ) VALUES (
                %(attachment_id)s, %(email_id)s, %(file_name)s, %(relative_path)s,
                %(sender)s, %(recipient)s, %(email_timestamp)s, %(body)s,
                %(is_read)s, %(send_to_agent)s, %(status)s
            )
        """
        try:
            with self.cursor() as cur:
                cur.execute(query, data)
                return True
        except psycopg2.IntegrityError:
            logger.warning(f"Duplicate attachment: {data.get('attachment_id')}")
            return False
    
    def update_attachment_agent_status(self, attachment_id: str, send_to_agent: bool = True) -> bool:
        """Mark attachment as sent to agent."""
        query = "UPDATE attachments SET send_to_agent = %s WHERE attachment_id = %s"
        with self.cursor() as cur:
            cur.execute(query, (send_to_agent, attachment_id))
            return cur.rowcount > 0
    
    def attachment_exists(self, attachment_id: str) -> bool:
        """Check if attachment exists."""
        query = "SELECT 1 FROM attachments WHERE attachment_id = %s LIMIT 1"
        with self.cursor() as cur:
            cur.execute(query, (attachment_id,))
            return cur.fetchone() is not None
    
    def get_attachment_stats(self) -> Dict[str, int]:
        """Get attachment statistics."""
        query = """
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN send_to_agent = FALSE THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN send_to_agent = TRUE THEN 1 ELSE 0 END) as processed,
                SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as errors
            FROM attachments
        """
        with self.cursor() as cur:
            cur.execute(query)
            result = cur.fetchone()
            return {
                "total": result["total"] or 0,
                "pending": result["pending"] or 0,
                "processed": result["processed"] or 0,
                "errors": result["errors"] or 0
            }
    
    # ========================================================================
    # AGENT JOB OPERATIONS
    # ========================================================================
    
    def create_job(self, data: Dict[str, Any]) -> bool:
        """Create new agent job."""
        query = """
            INSERT INTO agent_jobs (
                agent_job_id, attachment_id, agent_name, requested_by, status
            ) VALUES (
                %(agent_job_id)s, %(attachment_id)s, %(agent_name)s,
                %(requested_by)s, %(status)s
            )
        """
        try:
            with self.cursor() as cur:
                cur.execute(query, data)
                return True
        except Exception as e:
            logger.error(f"Failed to create job: {e}")
            return False
    
    def get_job_by_id(self, job_id: str) -> Optional[Dict[str, Any]]:
        """Get job by ID."""
        query = "SELECT * FROM agent_jobs WHERE agent_job_id = %s"
        with self.cursor() as cur:
            cur.execute(query, (job_id,))
            return cur.fetchone()
    
    def get_recent_jobs(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get recent jobs."""
        query = """
            SELECT j.*, a.file_name
            FROM agent_jobs j
            LEFT JOIN attachments a ON j.attachment_id = a.attachment_id
            ORDER BY j.created_at DESC
            LIMIT %s
        """
        with self.cursor() as cur:
            cur.execute(query, (limit,))
            return cur.fetchall()
    
    def update_job_status(self, job_id: str, status: str, 
                         result: str = None, error: str = None) -> bool:
        """Update job status."""
        query = """
            UPDATE agent_jobs
            SET status = %s, result = %s, error_message = %s, updated_at = CURRENT_TIMESTAMP
            WHERE agent_job_id = %s
        """
        with self.cursor() as cur:
            cur.execute(query, (status, result, error, job_id))
            return cur.rowcount > 0
    
    def get_job_stats(self) -> Dict[str, int]:
        """Get job statistics."""
        query = """
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'queued' THEN 1 ELSE 0 END) as queued,
                SUM(CASE WHEN status = 'running' THEN 1 ELSE 0 END) as running,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
            FROM agent_jobs
        """
        with self.cursor() as cur:
            cur.execute(query)
            result = cur.fetchone()
            return {
                "total": result["total"] or 0,
                "queued": result["queued"] or 0,
                "running": result["running"] or 0,
                "completed": result["completed"] or 0,
                "failed": result["failed"] or 0
            }


# Global database instance
db = Database()

"""
File Service
Handles file storage operations for email attachments.
"""
import os
import re
import hashlib
from pathlib import Path
from datetime import datetime, timezone
from typing import Tuple
import logging

from core.config import settings

logger = logging.getLogger(__name__)


class FileService:
    """Manages file storage with date-based organization."""
    
    def __init__(self):
        self.base_path = Path(settings.ATTACHMENT_PATH).resolve()
        self.base_path.mkdir(parents=True, exist_ok=True)
        logger.info(f"File storage initialized: {self.base_path}")
    
    def _sanitize_filename(self, filename: str) -> str:
        """Sanitize filename to prevent security issues."""
        # Remove path separators
        filename = filename.replace('/', '_').replace('\\', '_')
        
        # Remove dangerous characters
        filename = re.sub(r'[<>:"|?*]', '_', filename)
        
        # Replace multiple underscores
        filename = re.sub(r'_+', '_', filename)
        
        # Limit length
        name, ext = os.path.splitext(filename)
        if len(name) > 100:
            name = name[:100]
        
        return f"{name}{ext}"
    
    def _generate_unique_filename(self, directory: Path, filename: str) -> str:
        """Generate unique filename if file exists."""
        if not (directory / filename).exists():
            return filename
        
        name, ext = os.path.splitext(filename)
        counter = 1
        
        while (directory / filename).exists():
            hash_suffix = hashlib.md5(f"{name}{counter}".encode()).hexdigest()[:8]
            filename = f"{name}_{hash_suffix}{ext}"
            counter += 1
            
            if counter > 100:
                timestamp = datetime.now(timezone.utc).strftime('%H%M%S%f')
                filename = f"{name}_{timestamp}{ext}"
                break
        
        return filename
    
    def get_storage_directory(self) -> Tuple[Path, str]:
        """Get storage directory with date-based structure (YYYY/MM)."""
        now = datetime.now(timezone.utc)
        relative_dir = f"{now.year}/{now.month:02d}"
        full_path = self.base_path / relative_dir
        full_path.mkdir(parents=True, exist_ok=True)
        
        return full_path, relative_dir
    
    def save_file(self, filename: str, content: bytes) -> Tuple[str, str]:
        """
        Save file to storage.
        
        Args:
            filename: Original filename
            content: File content as bytes
        
        Returns:
            (relative_path, full_path)
        """
        # Get storage directory
        directory, relative_dir = self.get_storage_directory()
        
        # Sanitize and make unique
        safe_filename = self._sanitize_filename(filename)
        unique_filename = self._generate_unique_filename(directory, safe_filename)
        
        # Save file
        full_path = directory / unique_filename
        with open(full_path, 'wb') as f:
            f.write(content)
        
        relative_path = f"{relative_dir}/{unique_filename}"
        
        logger.info(f"Saved file: {relative_path} ({len(content)} bytes)")
        
        return relative_path, str(full_path)
    
    def file_exists(self, relative_path: str) -> bool:
        """Check if file exists."""
        return (self.base_path / relative_path).exists()
    
    def get_full_path(self, relative_path: str) -> str:
        """Get full path from relative path."""
        return str(self.base_path / relative_path)


# Global file service instance
file_service = FileService()

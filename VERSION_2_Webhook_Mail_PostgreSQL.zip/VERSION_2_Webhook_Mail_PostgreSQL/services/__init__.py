"""Services for email attachment processor."""
from services.email_service import email_service
from services.file_service import file_service

__all__ = ['email_service', 'file_service']

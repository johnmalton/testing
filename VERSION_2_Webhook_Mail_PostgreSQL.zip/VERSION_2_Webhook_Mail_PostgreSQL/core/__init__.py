"""Core modules for email attachment processor."""
from core.config import settings
from core.database import db
from core.auth import token_manager

__all__ = ['settings', 'db', 'token_manager']

# Email Attachment Processor

## Complete Production Guide

A production-grade FastAPI application for processing email attachments from Microsoft Outlook via Graph API, with REST API integration for SAP backend and AI agent processing.

---

## Table of Contents

1. [Introduction](#1-introduction)
2. [System Architecture](#2-system-architecture)
3. [Project Structure](#3-project-structure)
4. [Prerequisites](#4-prerequisites)
5. [Installation Guide](#5-installation-guide)
6. [Configuration](#6-configuration)
7. [Azure AD Setup](#7-azure-ad-setup)
8. [Database Setup](#8-database-setup)
9. [Running the Application](#9-running-the-application)
10. [API Reference](#10-api-reference)
11. [Workflow Guide](#11-workflow-guide)
12. [Scheduling & Automation](#12-scheduling--automation)
13. [Production Deployment](#13-production-deployment)
14. [Troubleshooting](#14-troubleshooting)
15. [Security Considerations](#15-security-considerations)

---

## 1. Introduction

### 1.1 Purpose

This application serves as a middleware between Microsoft Outlook email system and SAP backend for automated invoice/document processing. It:

- Fetches unread emails from a specified Outlook mailbox
- Downloads and stores email attachments securely
- Provides REST API for SAP backend to retrieve attachments
- Manages AI agent processing jobs
- Tracks processing status and provides audit capabilities

### 1.2 Key Features

| Feature | Description |
|---------|-------------|
| **OAuth2 Authentication** | Client Credentials flow for organizational accounts |
| **Auto Token Refresh** | Tokens refresh automatically before expiration |
| **Connection Pooling** | Efficient MySQL connection management |
| **Idempotent Processing** | Duplicate attachments are automatically skipped |
| **Structured Logging** | JSON logging for production environments |
| **Comprehensive Error Handling** | Consistent error responses across all endpoints |
| **Audit Trail** | Complete tracking of all operations |

### 1.3 Technology Stack

| Component | Technology |
|-----------|------------|
| Framework | FastAPI 0.109+ |
| Language | Python 3.10+ |
| Database | MySQL 8.0+ |
| HTTP Client | HTTPX |
| Validation | Pydantic v2 |
| Server | Uvicorn / Gunicorn |
| External API | Microsoft Graph API |

---

## 2. System Architecture

### 2.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              SYSTEM ARCHITECTURE                                 │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│    ┌────────────────┐                                                           │
│    │   Microsoft    │                                                           │
│    │   Azure AD     │◄─── OAuth2 Client Credentials                             │
│    └───────┬────────┘                                                           │
│            │ Access Token                                                        │
│            ▼                                                                     │
│    ┌────────────────┐         ┌────────────────┐         ┌────────────────┐    │
│    │   Microsoft    │  Fetch  │    FastAPI     │  Store  │     MySQL      │    │
│    │   Outlook      │────────▶│    Server      │────────▶│   Database     │    │
│    │   (Graph API)  │ Emails  │                │ Metadata│                │    │
│    └────────────────┘         └───────┬────────┘         └────────────────┘    │
│                                       │                                          │
│                                       │ Save Files                               │
│                                       ▼                                          │
│                               ┌────────────────┐                                │
│                               │   File System  │                                │
│                               │  (Attachments) │                                │
│                               └────────────────┘                                │
│                                       │                                          │
│                                       │ REST API                                 │
│                                       ▼                                          │
│                               ┌────────────────┐         ┌────────────────┐    │
│                               │  SAP Backend   │────────▶│   AI Agent     │    │
│                               │   (Consumer)   │ Process │  (Processor)   │    │
│                               └────────────────┘         └────────────────┘    │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Data Flow

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                                 DATA FLOW                                        │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│  1. EMAIL INGESTION (Scheduled)                                                 │
│     ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐   │
│     │ Refresh │───▶│  Fetch  │───▶│Download │───▶│  Save   │───▶│  Mark   │   │
│     │  Token  │    │ Emails  │    │Attachmt │    │  Files  │    │ As Read │   │
│     └─────────┘    └─────────┘    └─────────┘    └─────────┘    └─────────┘   │
│                                                         │                        │
│                                                         ▼                        │
│                                                  ┌─────────────┐                │
│                                                  │   MySQL DB  │                │
│                                                  │ (Metadata)  │                │
│                                                  └─────────────┘                │
│                                                         │                        │
│  2. API CONSUMPTION (On-Demand)                        │                        │
│     ┌─────────┐    ┌─────────┐    ┌─────────┐         │                        │
│     │   GET   │───▶│ Create  │───▶│ Update  │◄────────┘                        │
│     │  /next  │    │   Job   │    │ Status  │                                   │
│     └─────────┘    └─────────┘    └─────────┘                                   │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 2.3 Component Interaction

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           COMPONENT INTERACTION                                  │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │                              FastAPI App                                 │   │
│  ├─────────────────────────────────────────────────────────────────────────┤   │
│  │                                                                          │   │
│  │   ┌──────────────┐   ┌──────────────┐   ┌──────────────┐                │   │
│  │   │  Attachment  │   │     Job      │   │    Audit     │                │   │
│  │   │  Endpoints   │   │  Endpoints   │   │  Endpoints   │                │   │
│  │   └──────┬───────┘   └──────┬───────┘   └──────┬───────┘                │   │
│  │          │                  │                  │                         │   │
│  │          └──────────────────┼──────────────────┘                         │   │
│  │                             ▼                                            │   │
│  │                    ┌────────────────┐                                    │   │
│  │                    │   Repository   │                                    │   │
│  │                    │    (DB Ops)    │                                    │   │
│  │                    └────────┬───────┘                                    │   │
│  │                             │                                            │   │
│  │   ┌─────────────────────────┼─────────────────────────┐                 │   │
│  │   │                         ▼                         │                 │   │
│  │   │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │   │  │    Token     │  │    Email     │  │     File     │              │   │
│  │   │  │   Service    │  │   Service    │  │   Service    │              │   │
│  │   │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │   │       Services Layer                                               │   │
│  │   └────────────────────────────────────────────────────────────────────┘   │
│  │                                                                          │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Project Structure

```
email_attachment_processor/
│
├── app/                                    # Main Application Package
│   ├── __init__.py                         # Package initialization
│   ├── main.py                             # FastAPI application entry point
│   │
│   ├── core/                               # Core Functionality
│   │   ├── __init__.py
│   │   ├── config.py                       # Configuration management (Pydantic Settings)
│   │   ├── logging.py                      # Structured logging setup
│   │   ├── security.py                     # API key authentication
│   │   └── exceptions.py                   # Custom exception classes
│   │
│   ├── db/                                 # Database Layer
│   │   ├── __init__.py
│   │   ├── session.py                      # MySQL connection pooling
│   │   └── repository.py                   # Data access operations (CRUD)
│   │
│   ├── models/                             # Database Models (Reserved)
│   │   └── __init__.py
│   │
│   ├── schemas/                            # Pydantic Schemas
│   │   ├── __init__.py
│   │   ├── common.py                       # Shared response schemas
│   │   ├── attachment.py                   # Attachment request/response schemas
│   │   └── job.py                          # Job request/response schemas
│   │
│   ├── services/                           # Business Logic Services
│   │   ├── __init__.py
│   │   ├── token_service.py                # OAuth2 token management
│   │   ├── email_service.py                # Email fetching from Graph API
│   │   └── file_service.py                 # File storage operations
│   │
│   └── api/                                # API Routes
│       ├── __init__.py
│       ├── deps.py                         # Common dependencies
│       └── v1/                             # API Version 1
│           ├── __init__.py
│           ├── router.py                   # Main API router
│           └── endpoints/                  # Endpoint modules
│               ├── __init__.py
│               ├── attachments.py          # Attachment endpoints
│               ├── jobs.py                 # Agent job endpoints
│               └── audit.py                # Audit & monitoring endpoints
│
├── scripts/                                # Utility Scripts
│   ├── init_db.py                          # Database initialization
│   ├── refresh_token.py                    # Manual token refresh
│   └── fetch_emails.py                     # Email ingestion script
│
├── config/                                 # Configuration Files
│   └── token.json                          # OAuth token storage (auto-generated)
│
├── attachments/                            # Attachment Storage
│   └── YYYY/MM/                            # Date-based directory structure
│
├── logs/                                   # Log Files
│   └── app.log                             # Application logs
│
├── .env.example                            # Environment template
├── .env                                    # Environment variables (create from example)
├── .gitignore                              # Git ignore rules
├── requirements.txt                        # Python dependencies
├── run.py                                  # Easy startup script
└── GUIDE.md                                # This documentation
```

### 3.1 Module Descriptions

| Module | Purpose |
|--------|---------|
| `app/core/config.py` | Loads and validates all environment variables using Pydantic Settings |
| `app/core/logging.py` | Configures structured JSON logging for production |
| `app/core/security.py` | Implements API key authentication middleware |
| `app/core/exceptions.py` | Defines custom exception classes for consistent error handling |
| `app/db/session.py` | Manages MySQL connection pool using DBUtils |
| `app/db/repository.py` | Contains all database CRUD operations |
| `app/services/token_service.py` | Handles OAuth2 token acquisition and refresh |
| `app/services/email_service.py` | Fetches emails and attachments from Graph API |
| `app/services/file_service.py` | Manages file storage with secure naming |
| `app/api/v1/endpoints/attachments.py` | Attachment-related API endpoints |
| `app/api/v1/endpoints/jobs.py` | Agent job management endpoints |
| `app/api/v1/endpoints/audit.py` | System monitoring and audit endpoints |

---

## 4. Prerequisites

### 4.1 System Requirements

| Requirement | Minimum | Recommended |
|-------------|---------|-------------|
| Python | 3.10 | 3.11+ |
| MySQL | 8.0 | 8.0+ |
| RAM | 512 MB | 2 GB |
| Storage | 10 GB | 50 GB+ |
| OS | Any | Ubuntu 22.04 LTS |

### 4.2 Required Accounts & Access

| Account | Purpose | Required Permissions |
|---------|---------|---------------------|
| Azure AD | OAuth2 authentication | App registration, API permissions |
| Microsoft 365 | Email access | Mailbox access |
| MySQL | Data storage | CREATE, SELECT, INSERT, UPDATE, DELETE |

### 4.3 Network Requirements

| Service | Endpoint | Port |
|---------|----------|------|
| Azure AD | login.microsoftonline.com | 443 |
| Graph API | graph.microsoft.com | 443 |
| MySQL | localhost (configurable) | 3306 |

---

## 5. Installation Guide

### 5.1 Step-by-Step Installation

#### Step 1: Extract Project

```bash
# Extract the zip file
unzip email_attachment_processor.zip
cd email_attachment_processor
```

#### Step 2: Create Virtual Environment

```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# Linux/Mac:
source venv/bin/activate

# Windows:
venv\Scripts\activate
```

#### Step 3: Install Dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

#### Step 4: Configure Environment

```bash
# Copy environment template
cp .env.example .env

# Edit with your values
nano .env  # or use any text editor
```

#### Step 5: Initialize Database

```bash
python scripts/init_db.py
```

#### Step 6: Verify Token Acquisition

```bash
python scripts/refresh_token.py
```

#### Step 7: Test Email Fetching

```bash
python scripts/fetch_emails.py
```

#### Step 8: Start Server

```bash
python run.py
# OR
uvicorn app.main:app --host 0.0.0.0 --port 5000
```

### 5.2 Verification Checklist

| Check | Command | Expected Result |
|-------|---------|-----------------|
| Database | `python scripts/init_db.py` | "Database initialization completed" |
| Token | `python scripts/refresh_token.py` | "Token refreshed successfully" |
| Server | `curl http://localhost:5000/health` | `{"status": "healthy"}` |
| API | `curl -H "X-API-Key: your-key" http://localhost:5000/api/v1/attachments/stats` | JSON response |

---

## 6. Configuration

### 6.1 Environment Variables Reference

#### Application Settings

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `APP_NAME` | string | Email Attachment Processor | Application name |
| `APP_VERSION` | string | 1.0.0 | Application version |
| `DEBUG` | boolean | false | Enable debug mode |
| `ENVIRONMENT` | string | development | Environment (development/staging/production) |

#### API Security

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `API_KEY` | string | **Required** | API key for authentication (min 16 chars) |
| `API_KEY_HEADER` | string | X-API-Key | Header name for API key |

#### Database Configuration

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `DB_HOST` | string | localhost | MySQL host |
| `DB_PORT` | integer | 3306 | MySQL port |
| `DB_USER` | string | root | MySQL username |
| `DB_PASSWORD` | string | **Required** | MySQL password |
| `DB_NAME` | string | email_attachments | Database name |
| `DB_POOL_SIZE` | integer | 5 | Connection pool size |
| `DB_POOL_RECYCLE` | integer | 3600 | Connection recycle time (seconds) |

#### Azure AD Configuration

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `AZURE_TENANT_ID` | string | **Required** | Azure AD tenant ID (36 chars) |
| `AZURE_CLIENT_ID` | string | **Required** | Azure AD application ID (36 chars) |
| `AZURE_CLIENT_SECRET` | string | **Required** | Azure AD client secret |
| `GRAPH_API_VERSION` | string | v1.0 | Graph API version |
| `GRAPH_SCOPES` | string | https://graph.microsoft.com/.default | OAuth scopes |

#### Email Configuration

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `MAILBOX_EMAIL` | string | **Required** | Email address to fetch from |
| `MAILBOX_FOLDER` | string | Inbox | Outlook folder to monitor |
| `MAX_EMAILS_PER_FETCH` | integer | 50 | Maximum emails per fetch (1-100) |

#### Storage Configuration

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `ATTACHMENT_BASE_PATH` | path | attachments | Base path for attachments |
| `TOKEN_FILE_PATH` | path | config/token.json | Token storage file |
| `LOG_FILE_PATH` | path | logs/app.log | Log file path |

#### Processing Configuration

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `TOKEN_REFRESH_BUFFER_SECONDS` | integer | 300 | Refresh token before expiry (seconds) |
| `REQUEST_TIMEOUT_SECONDS` | integer | 60 | HTTP request timeout |

### 6.2 Sample .env File

```env
# =============================================================================
# Email Attachment Processor Configuration
# =============================================================================

# Application
APP_NAME=Email Attachment Processor
APP_VERSION=1.0.0
DEBUG=false
ENVIRONMENT=production

# API Security (Generate: python -c "import secrets; print(secrets.token_hex(32))")
API_KEY=a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6

# MySQL Database
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your-secure-mysql-password
DB_NAME=email_attachments
DB_POOL_SIZE=5

# Azure AD (from Azure Portal > App Registrations)
AZURE_TENANT_ID=12345678-1234-1234-1234-123456789012
AZURE_CLIENT_ID=87654321-4321-4321-4321-210987654321
AZURE_CLIENT_SECRET=your-client-secret-value-here

# Email Configuration
MAILBOX_EMAIL=invoices@yourcompany.com
MAILBOX_FOLDER=Inbox
MAX_EMAILS_PER_FETCH=50

# Storage
ATTACHMENT_BASE_PATH=attachments
TOKEN_FILE_PATH=config/token.json
LOG_FILE_PATH=logs/app.log
```

### 6.3 Generate API Key

```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

---

## 7. Azure AD Setup

### 7.1 Register Application

1. Navigate to [Azure Portal](https://portal.azure.com)
2. Go to **Azure Active Directory** → **App registrations**
3. Click **+ New registration**

#### Registration Settings

| Setting | Value |
|---------|-------|
| Name | Email Attachment Processor |
| Supported account types | Accounts in this organizational directory only |
| Redirect URI | Leave empty |

4. Click **Register**

### 7.2 Collect Application IDs

From the **Overview** page, copy:

| Value | Environment Variable |
|-------|---------------------|
| Application (client) ID | `AZURE_CLIENT_ID` |
| Directory (tenant) ID | `AZURE_TENANT_ID` |

### 7.3 Create Client Secret

1. Go to **Certificates & secrets**
2. Click **+ New client secret**
3. Configure:

| Setting | Value |
|---------|-------|
| Description | Email Processor Secret |
| Expires | 12 months (or as needed) |

4. Click **Add**
5. **Copy the Value immediately** → `AZURE_CLIENT_SECRET`

> ⚠️ **Important**: The secret value is only shown once. Copy it immediately.

### 7.4 Configure API Permissions

1. Go to **API permissions**
2. Click **+ Add a permission**
3. Select **Microsoft Graph**
4. Select **Application permissions** (NOT Delegated)
5. Add the following permissions:

| Permission | Description |
|------------|-------------|
| `Mail.Read` | Read mail in all mailboxes |
| `Mail.ReadWrite` | Read and write mail in all mailboxes |

6. Click **Add permissions**
7. Click **Grant admin consent for [Organization]**
8. Confirm by clicking **Yes**

### 7.5 Verification

After setup, verify in the API permissions page:

```
✓ Mail.Read         Application    Granted for [Organization]
✓ Mail.ReadWrite    Application    Granted for [Organization]
```

---

## 8. Database Setup

### 8.1 Create MySQL Database

```sql
-- Connect to MySQL
mysql -u root -p

-- Create database
CREATE DATABASE email_attachments
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

-- Verify
SHOW DATABASES LIKE 'email_attachments';
```

### 8.2 Run Initialization Script

```bash
python scripts/init_db.py
```

**Expected Output:**
```
======================================================================
  DATABASE INITIALIZATION
======================================================================

  Host: localhost:3306
  Database: email_attachments
  User: root

----------------------------------------------------------------------
Creating database: email_attachments
✓ Database 'email_attachments' ready
Creating tables...
✓ Table 'attachments' ready
✓ Table 'agent_jobs' ready
----------------------------------------------------------------------
Verifying tables...
  - attachments: 0 records
  - agent_jobs: 0 records
----------------------------------------------------------------------

✓ Database initialization completed successfully

======================================================================
```

### 8.3 Database Schema

#### Table: attachments

| Column | Type | Description |
|--------|------|-------------|
| id | INT | Auto-increment primary key |
| attachment_id | VARCHAR(100) | Unique attachment identifier |
| email_id | VARCHAR(500) | Source email ID from Graph API |
| file_name | VARCHAR(255) | Original filename |
| relative_path | VARCHAR(500) | Storage path relative to base |
| sender | VARCHAR(255) | Email sender address |
| recipient | VARCHAR(255) | Email recipient address |
| email_timestamp | DATETIME | Email received timestamp |
| email_incoming | TINYINT(1) | 1 = incoming email |
| body | TEXT | Email body content |
| is_read | TINYINT(1) | 1 = email marked as read |
| send_to_agent | TINYINT(1) | 1 = sent to AI agent |
| status | VARCHAR(50) | Processing status |
| processing_attempts | INT | Number of processing attempts |
| last_attempt | DATETIME | Last processing attempt timestamp |
| error_message | TEXT | Error message if failed |
| created_at | TIMESTAMP | Record creation timestamp |
| updated_at | TIMESTAMP | Record update timestamp |

#### Table: agent_jobs

| Column | Type | Description |
|--------|------|-------------|
| id | INT | Auto-increment primary key |
| agent_job_id | VARCHAR(100) | Unique job identifier |
| attachment_id | VARCHAR(100) | Associated attachment ID |
| agent_name | VARCHAR(100) | AI agent name |
| requested_by | VARCHAR(100) | Job requester |
| status | VARCHAR(50) | Job status |
| result | TEXT | Job result data |
| error_message | TEXT | Error message if failed |
| created_at | TIMESTAMP | Job creation timestamp |
| updated_at | TIMESTAMP | Job update timestamp |

### 8.4 Status Values

#### Attachment Status

| Status | Description |
|--------|-------------|
| `ready_for_sap` | Ready for processing |
| `processing` | Currently being processed |
| `completed` | Processing completed |
| `error` | Processing failed |

#### Job Status

| Status | Description |
|--------|-------------|
| `queued` | Job created, waiting |
| `running` | Job in progress |
| `completed` | Job completed successfully |
| `failed` | Job failed |

---

## 9. Running the Application

### 9.1 Development Mode

```bash
# Using run.py
python run.py --reload

# Using uvicorn directly
uvicorn app.main:app --reload --port 5000

# With custom host
uvicorn app.main:app --host 0.0.0.0 --port 5000 --reload
```

### 9.2 Production Mode

```bash
# Using uvicorn with workers
uvicorn app.main:app --host 0.0.0.0 --port 5000 --workers 4

# Using gunicorn (recommended for production)
gunicorn app.main:app -w 4 -k uvicorn.workers.UvicornWorker -b 0.0.0.0:5000
```

### 9.3 Run Script Options

```bash
python run.py --help

Options:
  --host      Host to bind (default: 0.0.0.0)
  --port      Port to bind (default: 5000)
  --reload    Enable auto-reload (development)
  --workers   Number of workers (default: 1)
```

### 9.4 Verify Server

```bash
# Health check
curl http://localhost:5000/health

# Expected response
{
  "status": "healthy",
  "timestamp": "2025-12-14T10:00:00Z",
  "database": "connected",
  "version": "1.0.0"
}
```

---

## 10. API Reference

### 10.1 Authentication

All endpoints (except `/health`) require API key authentication.

**Header:**
```
X-API-Key: your-api-key-here
```

**Error Response (401):**
```json
{
  "meta": {
    "request_id": "uuid",
    "api_version": "v1",
    "timestamp": "2025-12-14T10:00:00Z"
  },
  "error": {
    "code": "INVALID_API_KEY",
    "message": "Invalid API key"
  }
}
```

### 10.2 Base URL

```
http://localhost:5000/api/v1
```

### 10.3 Response Format

All responses follow this structure:

**Success Response:**
```json
{
  "meta": {
    "request_id": "550e8400-e29b-41d4-a716-446655440000",
    "api_version": "v1",
    "timestamp": "2025-12-14T10:00:00Z"
  },
  "data": { ... }
}
```

**Error Response:**
```json
{
  "meta": {
    "request_id": "550e8400-e29b-41d4-a716-446655440000",
    "api_version": "v1",
    "timestamp": "2025-12-14T10:00:00Z"
  },
  "error": {
    "code": "ERROR_CODE",
    "message": "Human readable message",
    "details": { ... }
  }
}
```

---

### 10.4 Attachment Endpoints

#### GET /api/v1/attachments/next

Get the next attachment ready for processing.

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `newest_first` | boolean | false | If true, return newest first (LIFO) |

**Request:**
```bash
curl -X GET "http://localhost:5000/api/v1/attachments/next" \
  -H "X-API-Key: your-api-key"

# Get newest first
curl -X GET "http://localhost:5000/api/v1/attachments/next?newest_first=true" \
  -H "X-API-Key: your-api-key"
```

**Response (200):**
```json
{
  "meta": {
    "request_id": "uuid",
    "api_version": "v1",
    "timestamp": "2025-12-14T10:00:00Z"
  },
  "attachment": {
    "attachment_id": "att_20251214_100000_abc123",
    "email_id": "AAMkAGI2TG93AAA=",
    "file_name": "invoice_001.pdf",
    "relative_path": "2025/12/invoice_001.pdf",
    "sender": "vendor@example.com",
    "recipient": "invoices@company.com",
    "email_timestamp": "2025-12-14T09:30:00Z",
    "status": "ready_for_sap",
    "flags": {
      "is_read": true,
      "send_to_agent": false
    }
  }
}
```

**Response (204):** No attachment available (empty response)

---

#### GET /api/v1/attachments/pending

Get all pending attachments.

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `limit` | integer | 100 | Maximum results (1-500) |

**Request:**
```bash
curl -X GET "http://localhost:5000/api/v1/attachments/pending?limit=50" \
  -H "X-API-Key: your-api-key"
```

**Response (200):**
```json
{
  "meta": { ... },
  "total_count": 5,
  "attachments": [
    {
      "attachment_id": "att_20251214_100000_abc123",
      "email_id": "AAMkAGI2TG93AAA=",
      "file_name": "invoice_001.pdf",
      "sender": "vendor@example.com",
      "recipient": "invoices@company.com",
      "email_timestamp": "2025-12-14T09:30:00Z",
      "status": "ready_for_sap",
      "created_at": "2025-12-14T09:31:00Z"
    }
  ]
}
```

---

#### GET /api/v1/attachments/processed

Get processed attachments (sent to agent).

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `limit` | integer | 100 | Maximum results (1-500) |

**Request:**
```bash
curl -X GET "http://localhost:5000/api/v1/attachments/processed" \
  -H "X-API-Key: your-api-key"
```

---

#### GET /api/v1/attachments/failed

Get failed attachments.

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `limit` | integer | 100 | Maximum results (1-500) |

**Request:**
```bash
curl -X GET "http://localhost:5000/api/v1/attachments/failed" \
  -H "X-API-Key: your-api-key"
```

---

#### GET /api/v1/attachments/stats

Get attachment statistics.

**Request:**
```bash
curl -X GET "http://localhost:5000/api/v1/attachments/stats" \
  -H "X-API-Key: your-api-key"
```

**Response (200):**
```json
{
  "meta": { ... },
  "stats": {
    "total": 150,
    "pending": 10,
    "processed": 135,
    "failed": 5
  }
}
```

---

#### GET /api/v1/attachments/{attachment_id}

Get a specific attachment by ID.

**Path Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `attachment_id` | string | Unique attachment identifier |

**Request:**
```bash
curl -X GET "http://localhost:5000/api/v1/attachments/att_20251214_100000_abc123" \
  -H "X-API-Key: your-api-key"
```

**Response (200):**
```json
{
  "meta": { ... },
  "attachment": {
    "attachment_id": "att_20251214_100000_abc123",
    "email_id": "AAMkAGI2TG93AAA=",
    "file_name": "invoice_001.pdf",
    "relative_path": "2025/12/invoice_001.pdf",
    "sender": "vendor@example.com",
    "recipient": "invoices@company.com",
    "email_timestamp": "2025-12-14T09:30:00Z",
    "status": "ready_for_sap",
    "flags": {
      "is_read": true,
      "send_to_agent": false
    }
  }
}
```

**Response (404):**
```json
{
  "meta": { ... },
  "error": {
    "code": "ATTACHMENT_NOT_FOUND",
    "message": "Attachment not found: att_invalid_id",
    "details": {
      "attachment_id": "att_invalid_id"
    }
  }
}
```

---

### 10.5 Job Endpoints

#### POST /api/v1/agent-jobs

Create a new agent job.

**Request Body:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `attachment_id` | string | Yes | Attachment ID to process |
| `agent_name` | string | Yes | Name of the AI agent |
| `requested_by` | string | Yes | Requester identifier |

**Request:**
```bash
curl -X POST "http://localhost:5000/api/v1/agent-jobs" \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "attachment_id": "att_20251214_100000_abc123",
    "agent_name": "sap_invoice_processor",
    "requested_by": "sap_backend"
  }'
```

**Response (201):**
```json
{
  "meta": { ... },
  "job": {
    "agent_job_id": "job_20251214_100100_def456",
    "attachment_id": "att_20251214_100000_abc123",
    "file_name": "invoice_001.pdf",
    "relative_path": "2025/12/invoice_001.pdf",
    "agent_name": "sap_invoice_processor",
    "requested_by": "sap_backend",
    "status": "queued",
    "result": null,
    "error_message": null,
    "created_at": "2025-12-14T10:01:00Z",
    "updated_at": null
  }
}
```

**Error Responses:**

| Code | Status | Description |
|------|--------|-------------|
| 404 | Not Found | Attachment not found |
| 409 | Conflict | Attachment already processed |
| 409 | Conflict | Attachment not ready |

---

#### GET /api/v1/agent-jobs

List all jobs.

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `status` | string | null | Filter by status |
| `limit` | integer | 100 | Maximum results (1-500) |
| `offset` | integer | 0 | Pagination offset |

**Request:**
```bash
# Get all jobs
curl -X GET "http://localhost:5000/api/v1/agent-jobs" \
  -H "X-API-Key: your-api-key"

# Filter by status
curl -X GET "http://localhost:5000/api/v1/agent-jobs?status=completed&limit=50" \
  -H "X-API-Key: your-api-key"
```

**Response (200):**
```json
{
  "meta": { ... },
  "total_count": 25,
  "jobs": [
    {
      "agent_job_id": "job_20251214_100100_def456",
      "attachment_id": "att_20251214_100000_abc123",
      "file_name": "invoice_001.pdf",
      "agent_name": "sap_invoice_processor",
      "requested_by": "sap_backend",
      "status": "completed",
      "created_at": "2025-12-14T10:01:00Z"
    }
  ]
}
```

---

#### GET /api/v1/agent-jobs/queued

Get queued jobs.

**Request:**
```bash
curl -X GET "http://localhost:5000/api/v1/agent-jobs/queued" \
  -H "X-API-Key: your-api-key"
```

---

#### GET /api/v1/agent-jobs/running

Get running jobs.

**Request:**
```bash
curl -X GET "http://localhost:5000/api/v1/agent-jobs/running" \
  -H "X-API-Key: your-api-key"
```

---

#### GET /api/v1/agent-jobs/stats

Get job statistics.

**Request:**
```bash
curl -X GET "http://localhost:5000/api/v1/agent-jobs/stats" \
  -H "X-API-Key: your-api-key"
```

**Response (200):**
```json
{
  "meta": { ... },
  "stats": {
    "total": 100,
    "queued": 5,
    "running": 2,
    "completed": 90,
    "failed": 3
  }
}
```

---

#### GET /api/v1/agent-jobs/{job_id}

Get a specific job by ID.

**Request:**
```bash
curl -X GET "http://localhost:5000/api/v1/agent-jobs/job_20251214_100100_def456" \
  -H "X-API-Key: your-api-key"
```

**Response (200):**
```json
{
  "meta": { ... },
  "job": {
    "agent_job_id": "job_20251214_100100_def456",
    "attachment_id": "att_20251214_100000_abc123",
    "file_name": "invoice_001.pdf",
    "relative_path": "2025/12/invoice_001.pdf",
    "agent_name": "sap_invoice_processor",
    "requested_by": "sap_backend",
    "status": "completed",
    "result": "Invoice processed successfully. Amount: 5000 SAR",
    "error_message": null,
    "created_at": "2025-12-14T10:01:00Z",
    "updated_at": "2025-12-14T10:02:00Z"
  }
}
```

---

#### PATCH /api/v1/agent-jobs/{job_id}

Update job status.

**Request Body:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `status` | string | Yes | New status: running, completed, failed |
| `result` | string | No | Job result (for completed) |
| `error_message` | string | No | Error message (for failed) |

**Request (Mark as Running):**
```bash
curl -X PATCH "http://localhost:5000/api/v1/agent-jobs/job_20251214_100100_def456" \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "status": "running"
  }'
```

**Request (Mark as Completed):**
```bash
curl -X PATCH "http://localhost:5000/api/v1/agent-jobs/job_20251214_100100_def456" \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "status": "completed",
    "result": "Invoice processed successfully. Vendor: ABC Corp, Amount: 5000 SAR, Due: 2025-01-14"
  }'
```

**Request (Mark as Failed):**
```bash
curl -X PATCH "http://localhost:5000/api/v1/agent-jobs/job_20251214_100100_def456" \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "status": "failed",
    "error_message": "PDF parsing failed: Invalid format"
  }'
```

---

### 10.6 Audit Endpoints

#### GET /api/v1/audit/health

Detailed health check (no authentication required).

**Request:**
```bash
curl -X GET "http://localhost:5000/api/v1/audit/health"
```

**Response (200):**
```json
{
  "status": "healthy",
  "timestamp": "2025-12-14T10:00:00Z",
  "version": "1.0.0",
  "components": {
    "database": "ok",
    "token": "ok",
    "storage": "ok"
  }
}
```

---

#### GET /api/v1/audit/stats

Get comprehensive system statistics.

**Request:**
```bash
curl -X GET "http://localhost:5000/api/v1/audit/stats" \
  -H "X-API-Key: your-api-key"
```

**Response (200):**
```json
{
  "meta": { ... },
  "attachments": {
    "total": 150,
    "pending": 10,
    "processed": 135,
    "failed": 5
  },
  "jobs": {
    "total": 135,
    "queued": 5,
    "running": 2,
    "completed": 125,
    "failed": 3
  },
  "storage": {
    "base_path": "/app/attachments",
    "total_files": 150,
    "total_size_bytes": 524288000,
    "total_size_mb": 500.0
  },
  "token": {
    "is_valid": true,
    "expires_at": "2025-12-14T11:00:00Z",
    "expires_in_seconds": 3540
  },
  "database": {
    "status": "active",
    "max_connections": 5,
    "host": "localhost",
    "database": "email_attachments"
  }
}
```

---

#### GET /api/v1/audit/token

Get token status.

**Request:**
```bash
curl -X GET "http://localhost:5000/api/v1/audit/token" \
  -H "X-API-Key: your-api-key"
```

**Response (200):**
```json
{
  "meta": { ... },
  "token": {
    "is_valid": true,
    "token_type": "Bearer",
    "expires_at": "2025-12-14T11:00:00Z",
    "acquired_at": "2025-12-14T10:00:00Z",
    "expires_in_seconds": 3540
  }
}
```

---

#### POST /api/v1/audit/token/refresh

Force token refresh.

**Request:**
```bash
curl -X POST "http://localhost:5000/api/v1/audit/token/refresh" \
  -H "X-API-Key: your-api-key"
```

**Response (200):**
```json
{
  "meta": { ... },
  "message": "Token refreshed successfully",
  "token": {
    "is_valid": true,
    "expires_at": "2025-12-14T11:05:00Z",
    "expires_in_seconds": 3600
  }
}
```

---

#### POST /api/v1/audit/ingest

Manually trigger email ingestion.

**Request:**
```bash
curl -X POST "http://localhost:5000/api/v1/audit/ingest" \
  -H "X-API-Key: your-api-key"
```

**Response (200):**
```json
{
  "meta": { ... },
  "result": {
    "emails_processed": 5,
    "emails_with_attachments": 3,
    "attachments_saved": 4,
    "attachments_skipped": 1,
    "errors": [],
    "start_time": "2025-12-14T10:00:00Z",
    "end_time": "2025-12-14T10:00:15Z",
    "duration_seconds": 15.5
  }
}
```

---

#### GET /api/v1/audit/config

Get non-sensitive configuration.

**Request:**
```bash
curl -X GET "http://localhost:5000/api/v1/audit/config" \
  -H "X-API-Key: your-api-key"
```

**Response (200):**
```json
{
  "meta": { ... },
  "config": {
    "app_name": "Email Attachment Processor",
    "app_version": "1.0.0",
    "environment": "production",
    "mailbox_email": "invoices@company.com",
    "mailbox_folder": "Inbox",
    "max_emails_per_fetch": 50,
    "db_host": "localhost",
    "db_name": "email_attachments",
    "attachment_path": "/app/attachments"
  }
}
```

---

### 10.7 Root Endpoints

#### GET /

API information.

**Request:**
```bash
curl -X GET "http://localhost:5000/"
```

**Response (200):**
```json
{
  "name": "Email Attachment Processor",
  "version": "1.0.0",
  "description": "Email Attachment Processor API",
  "documentation": "/docs",
  "endpoints": {
    "attachments": "/api/v1/attachments",
    "jobs": "/api/v1/agent-jobs",
    "audit": "/api/v1/audit",
    "health": "/health"
  }
}
```

---

#### GET /health

Quick health check.

**Request:**
```bash
curl -X GET "http://localhost:5000/health"
```

**Response (200):**
```json
{
  "status": "healthy",
  "timestamp": "2025-12-14T10:00:00Z",
  "database": "connected",
  "version": "1.0.0"
}
```

---

### 10.8 Complete Endpoint Summary

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/` | No | API information |
| GET | `/health` | No | Quick health check |
| GET | `/api/v1/attachments/next` | Yes | Get next attachment |
| GET | `/api/v1/attachments/pending` | Yes | List pending attachments |
| GET | `/api/v1/attachments/processed` | Yes | List processed attachments |
| GET | `/api/v1/attachments/failed` | Yes | List failed attachments |
| GET | `/api/v1/attachments/stats` | Yes | Attachment statistics |
| GET | `/api/v1/attachments/{id}` | Yes | Get specific attachment |
| POST | `/api/v1/agent-jobs` | Yes | Create job |
| GET | `/api/v1/agent-jobs` | Yes | List jobs |
| GET | `/api/v1/agent-jobs/queued` | Yes | List queued jobs |
| GET | `/api/v1/agent-jobs/running` | Yes | List running jobs |
| GET | `/api/v1/agent-jobs/stats` | Yes | Job statistics |
| GET | `/api/v1/agent-jobs/{id}` | Yes | Get specific job |
| PATCH | `/api/v1/agent-jobs/{id}` | Yes | Update job status |
| GET | `/api/v1/audit/health` | No | Detailed health check |
| GET | `/api/v1/audit/stats` | Yes | System statistics |
| GET | `/api/v1/audit/token` | Yes | Token status |
| POST | `/api/v1/audit/token/refresh` | Yes | Force token refresh |
| POST | `/api/v1/audit/ingest` | Yes | Trigger email ingestion |
| GET | `/api/v1/audit/config` | Yes | View configuration |

---

## 11. Workflow Guide

### 11.1 Complete Processing Flow

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           COMPLETE WORKFLOW                                      │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│  ┌────────────────────────────────────────────────────────────────────────────┐ │
│  │ PHASE 1: TOKEN MANAGEMENT (Automated - Every 55 minutes)                   │ │
│  ├────────────────────────────────────────────────────────────────────────────┤ │
│  │                                                                             │ │
│  │   python scripts/refresh_token.py                                          │ │
│  │                                                                             │ │
│  │   ┌─────────────┐     ┌─────────────┐     ┌─────────────┐                 │ │
│  │   │   Check     │────▶│   Acquire   │────▶│    Save     │                 │ │
│  │   │   Expiry    │     │  New Token  │     │   to File   │                 │ │
│  │   └─────────────┘     └─────────────┘     └─────────────┘                 │ │
│  │                                                                             │ │
│  └────────────────────────────────────────────────────────────────────────────┘ │
│                                      │                                           │
│                                      ▼                                           │
│  ┌────────────────────────────────────────────────────────────────────────────┐ │
│  │ PHASE 2: EMAIL INGESTION (Automated - Every 5 minutes)                     │ │
│  ├────────────────────────────────────────────────────────────────────────────┤ │
│  │                                                                             │ │
│  │   python scripts/fetch_emails.py                                           │ │
│  │                                                                             │ │
│  │   ┌─────────┐   ┌─────────┐   ┌─────────┐   ┌─────────┐   ┌─────────┐    │ │
│  │   │  Fetch  │──▶│  Check  │──▶│Download │──▶│  Save   │──▶│  Mark   │    │ │
│  │   │ Unread  │   │ Attach- │   │  Files  │   │Metadata │   │ As Read │    │ │
│  │   │ Emails  │   │  ments  │   │         │   │   DB    │   │         │    │ │
│  │   └─────────┘   └─────────┘   └─────────┘   └─────────┘   └─────────┘    │ │
│  │                                                                             │ │
│  │   Result: Attachments saved with status = 'ready_for_sap'                  │ │
│  │                                                                             │ │
│  └────────────────────────────────────────────────────────────────────────────┘ │
│                                      │                                           │
│                                      ▼                                           │
│  ┌────────────────────────────────────────────────────────────────────────────┐ │
│  │ PHASE 3: API SERVER (Always Running)                                       │ │
│  ├────────────────────────────────────────────────────────────────────────────┤ │
│  │                                                                             │ │
│  │   uvicorn app.main:app --host 0.0.0.0 --port 5000                          │ │
│  │                                                                             │ │
│  │   Provides REST API for SAP backend consumption                            │ │
│  │                                                                             │ │
│  └────────────────────────────────────────────────────────────────────────────┘ │
│                                      │                                           │
│                                      ▼                                           │
│  ┌────────────────────────────────────────────────────────────────────────────┐ │
│  │ PHASE 4: SAP BACKEND CONSUMPTION (On-Demand)                               │ │
│  ├────────────────────────────────────────────────────────────────────────────┤ │
│  │                                                                             │ │
│  │   Step 1: GET /api/v1/attachments/next                                     │ │
│  │           └──▶ Retrieve next pending attachment                            │ │
│  │                                                                             │ │
│  │   Step 2: POST /api/v1/agent-jobs                                          │ │
│  │           └──▶ Create job, marks attachment as sent (send_to_agent = 1)    │ │
│  │                                                                             │ │
│  │   Step 3: [Process with AI Agent]                                          │ │
│  │           └──▶ External AI processing                                      │ │
│  │                                                                             │ │
│  │   Step 4: PATCH /api/v1/agent-jobs/{id}                                    │ │
│  │           └──▶ Update job status (completed/failed)                        │ │
│  │                                                                             │ │
│  └────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 11.2 SAP Backend Integration Example

```python
import requests

BASE_URL = "http://localhost:5000/api/v1"
API_KEY = "your-api-key"
HEADERS = {"X-API-Key": API_KEY, "Content-Type": "application/json"}

def process_next_attachment():
    # Step 1: Get next attachment
    response = requests.get(f"{BASE_URL}/attachments/next", headers=HEADERS)
    
    if response.status_code == 204:
        print("No attachments available")
        return None
    
    attachment = response.json()["attachment"]
    attachment_id = attachment["attachment_id"]
    file_path = attachment["relative_path"]
    
    print(f"Processing: {attachment['file_name']}")
    
    # Step 2: Create job
    job_response = requests.post(
        f"{BASE_URL}/agent-jobs",
        headers=HEADERS,
        json={
            "attachment_id": attachment_id,
            "agent_name": "sap_invoice_processor",
            "requested_by": "sap_backend"
        }
    )
    
    job = job_response.json()["job"]
    job_id = job["agent_job_id"]
    
    # Step 3: Update to running
    requests.patch(
        f"{BASE_URL}/agent-jobs/{job_id}",
        headers=HEADERS,
        json={"status": "running"}
    )
    
    # Step 4: Process with AI (your logic here)
    try:
        result = process_with_ai(file_path)
        
        # Step 5: Mark as completed
        requests.patch(
            f"{BASE_URL}/agent-jobs/{job_id}",
            headers=HEADERS,
            json={
                "status": "completed",
                "result": result
            }
        )
        
    except Exception as e:
        # Mark as failed
        requests.patch(
            f"{BASE_URL}/agent-jobs/{job_id}",
            headers=HEADERS,
            json={
                "status": "failed",
                "error_message": str(e)
            }
        )
    
    return job_id
```

---

## 12. Scheduling & Automation

### 12.1 Linux Cron Jobs

Edit crontab:
```bash
crontab -e
```

Add these entries:
```bash
# Token refresh every 55 minutes
*/55 * * * * cd /path/to/project && /path/to/venv/bin/python scripts/refresh_token.py >> /path/to/logs/token.log 2>&1

# Email ingestion every 5 minutes
*/5 * * * * cd /path/to/project && /path/to/venv/bin/python scripts/fetch_emails.py >> /path/to/logs/emails.log 2>&1
```

### 12.2 Windows Task Scheduler

#### Token Refresh Task

1. Open Task Scheduler
2. Create Basic Task
3. Name: "Email Processor - Token Refresh"
4. Trigger: Daily, repeat every 55 minutes
5. Action: Start a program
   - Program: `C:\path\to\venv\Scripts\python.exe`
   - Arguments: `scripts\refresh_token.py`
   - Start in: `C:\path\to\project`

#### Email Ingestion Task

1. Create Basic Task
2. Name: "Email Processor - Email Ingestion"
3. Trigger: Daily, repeat every 5 minutes
4. Action: Start a program
   - Program: `C:\path\to\venv\Scripts\python.exe`
   - Arguments: `scripts\fetch_emails.py`
   - Start in: `C:\path\to\project`

### 12.3 Systemd Timer (Alternative to Cron)

Create `/etc/systemd/system/email-ingestion.service`:
```ini
[Unit]
Description=Email Ingestion Service

[Service]
Type=oneshot
User=www-data
WorkingDirectory=/path/to/project
ExecStart=/path/to/venv/bin/python scripts/fetch_emails.py
```

Create `/etc/systemd/system/email-ingestion.timer`:
```ini
[Unit]
Description=Run email ingestion every 5 minutes

[Timer]
OnCalendar=*:0/5
Persistent=true

[Install]
WantedBy=timers.target
```

Enable:
```bash
sudo systemctl enable email-ingestion.timer
sudo systemctl start email-ingestion.timer
```

---

## 13. Production Deployment

### 13.1 Gunicorn Configuration

Create `gunicorn.conf.py`:
```python
bind = "0.0.0.0:5000"
workers = 4
worker_class = "uvicorn.workers.UvicornWorker"
timeout = 120
keepalive = 5
errorlog = "/path/to/logs/gunicorn-error.log"
accesslog = "/path/to/logs/gunicorn-access.log"
loglevel = "info"
```

Run:
```bash
gunicorn app.main:app -c gunicorn.conf.py
```

### 13.2 Systemd Service

Create `/etc/systemd/system/email-processor.service`:
```ini
[Unit]
Description=Email Attachment Processor API
After=network.target mysql.service

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/path/to/project
Environment="PATH=/path/to/project/venv/bin"
EnvironmentFile=/path/to/project/.env
ExecStart=/path/to/project/venv/bin/gunicorn app.main:app -c gunicorn.conf.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable email-processor
sudo systemctl start email-processor
sudo systemctl status email-processor
```

### 13.3 Nginx Reverse Proxy

Create `/etc/nginx/sites-available/email-processor`:
```nginx
server {
    listen 80;
    server_name api.yourcompany.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable:
```bash
sudo ln -s /etc/nginx/sites-available/email-processor /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 13.4 Docker Deployment

Create `Dockerfile`:
```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

RUN mkdir -p config logs attachments

EXPOSE 5000

CMD ["gunicorn", "app.main:app", "-w", "4", "-k", "uvicorn.workers.UvicornWorker", "-b", "0.0.0.0:5000"]
```

Create `docker-compose.yml`:
```yaml
version: '3.8'

services:
  api:
    build: .
    ports:
      - "5000:5000"
    env_file:
      - .env
    volumes:
      - ./attachments:/app/attachments
      - ./logs:/app/logs
      - ./config:/app/config
    depends_on:
      - db
    restart: always

  db:
    image: mysql:8.0
    environment:
      MYSQL_ROOT_PASSWORD: ${DB_PASSWORD}
      MYSQL_DATABASE: ${DB_NAME}
    volumes:
      - mysql_data:/var/lib/mysql
    restart: always

volumes:
  mysql_data:
```

Run:
```bash
docker-compose up -d
```

---

## 14. Troubleshooting

### 14.1 Common Issues and Solutions

#### Token Errors

**Error:** "Authentication failed"

**Solutions:**
```bash
# 1. Refresh token manually
python scripts/refresh_token.py

# 2. Check Azure AD configuration
- Verify AZURE_CLIENT_ID is correct
- Verify AZURE_CLIENT_SECRET hasn't expired
- Verify AZURE_TENANT_ID is correct
- Ensure admin consent is granted
```

**Error:** "Token expired"

**Solution:**
```bash
# Token should auto-refresh, but if not:
python scripts/refresh_token.py

# Or via API:
curl -X POST "http://localhost:5000/api/v1/audit/token/refresh" \
  -H "X-API-Key: your-api-key"
```

---

#### Database Errors

**Error:** "Can't connect to MySQL server"

**Solutions:**
```bash
# 1. Check MySQL is running
sudo systemctl status mysql

# 2. Start MySQL if not running
sudo systemctl start mysql

# 3. Verify credentials
mysql -h localhost -u root -p

# 4. Re-initialize database
python scripts/init_db.py
```

**Error:** "Access denied for user"

**Solution:**
Check DB_USER and DB_PASSWORD in .env file.

---

#### Email Fetching Errors

**Error:** "No emails being fetched"

**Checklist:**
1. Verify MAILBOX_EMAIL is correct
2. Check there are unread emails in the folder
3. Verify Azure AD permissions (Mail.Read, Mail.ReadWrite)
4. Ensure admin consent is granted
5. Check token is valid: `python scripts/refresh_token.py`

**Error:** "Attachment already exists"

**Explanation:** This is normal - duplicates are skipped intentionally.

---

#### API Errors

**Error:** "Invalid API key"

**Solutions:**
1. Ensure `X-API-Key` header is included
2. Verify API_KEY in .env matches the header value
3. Check for extra spaces in the key

**Error:** "Attachment not found"

**Solution:** Verify attachment_id exists:
```bash
curl -X GET "http://localhost:5000/api/v1/attachments/pending" \
  -H "X-API-Key: your-api-key"
```

---

### 14.2 Logging and Debugging

#### Enable Debug Mode

In `.env`:
```env
DEBUG=true
```

#### View Logs

```bash
# Application logs
tail -f logs/app.log

# Token refresh logs
tail -f logs/token.log

# Email ingestion logs
tail -f logs/emails.log
```

#### Check System Status

```bash
# Health check
curl http://localhost:5000/health

# Detailed stats
curl -H "X-API-Key: your-key" http://localhost:5000/api/v1/audit/stats

# Token status
curl -H "X-API-Key: your-key" http://localhost:5000/api/v1/audit/token
```

---

## 15. Security Considerations

### 15.1 API Key Security

- Generate strong API keys (32+ characters)
- Rotate keys periodically
- Never commit API keys to version control
- Use different keys for different environments

### 15.2 Azure AD Security

- Use client secrets with appropriate expiration
- Grant minimum required permissions
- Monitor Azure AD sign-in logs
- Rotate client secrets before expiration

### 15.3 Database Security

- Use strong passwords
- Limit database user permissions
- Enable SSL for database connections
- Regular backups

### 15.4 File Storage Security

- Sanitize filenames (handled automatically)
- Set appropriate file permissions
- Consider encryption for sensitive files
- Regular cleanup of old files

### 15.5 Network Security

- Use HTTPS in production
- Configure firewall rules
- Use reverse proxy (nginx)
- Rate limiting

---

## Quick Reference

### Commands Cheat Sheet

```bash
# Setup
pip install -r requirements.txt
cp .env.example .env
python scripts/init_db.py

# Token
python scripts/refresh_token.py

# Email Ingestion
python scripts/fetch_emails.py

# Start Server
python run.py
uvicorn app.main:app --port 5000 --reload

# Production
gunicorn app.main:app -w 4 -k uvicorn.workers.UvicornWorker -b 0.0.0.0:5000

# Generate API Key
python -c "import secrets; print(secrets.token_hex(32))"
```

### API Quick Reference

```bash
# Health
curl http://localhost:5000/health

# Get next attachment
curl -H "X-API-Key: KEY" http://localhost:5000/api/v1/attachments/next

# Create job
curl -X POST -H "X-API-Key: KEY" -H "Content-Type: application/json" \
  -d '{"attachment_id":"ID","agent_name":"NAME","requested_by":"SAP"}' \
  http://localhost:5000/api/v1/agent-jobs

# Update job
curl -X PATCH -H "X-API-Key: KEY" -H "Content-Type: application/json" \
  -d '{"status":"completed","result":"Success"}' \
  http://localhost:5000/api/v1/agent-jobs/JOB_ID

# System stats
curl -H "X-API-Key: KEY" http://localhost:5000/api/v1/audit/stats
```

---

## Support

For issues, check:
1. Application logs: `logs/app.log`
2. Health endpoint: `/health`
3. System stats: `/api/v1/audit/stats`
4. Token status: `/api/v1/audit/token`

---

**Version:** 1.0.0  
**Last Updated:** December 2025  
**Author:** HOFT Global
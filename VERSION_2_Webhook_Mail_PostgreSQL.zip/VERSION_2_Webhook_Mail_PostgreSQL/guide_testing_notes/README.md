# Email Attachment Processor - Organizational Version

**Production-grade FastAPI application for processing email attachments from Microsoft Outlook** (Organizational/Work Accounts)

---

## ⚡ Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Configure (edit .env)
cp .env.example .env

# 3. Setup database
python scripts/init_db.py

# 4. Authenticate
python scripts/auth_setup.py

# 5. Fetch emails
python scripts/fetch_emails.py

# 6. Start server
python main.py
```

Visit `http://localhost:5000/docs` for interactive API documentation.

---

## 🎯 Must-Have Endpoints

### 1. GET /api/v1/attachments/next
Get next attachment for processing (FIFO)

### 2. POST /api/v1/agent-jobs
Create job to send attachment to agent

---

## 📁 Project Structure

```
email_processor_org/
├── core/               # Core modules
│   ├── config.py      # Configuration
│   ├── database.py    # Database operations
│   └── auth.py        # Token management (Client Credentials)
├── services/          # Business logic
│   ├── email_service.py
│   └── file_service.py
├── api/               # API endpoints
│   ├── attachments.py
│   ├── jobs.py
│   └── audit.py
├── scripts/           # Utilities
│   ├── init_db.py
│   ├── auth_setup.py
│   └── fetch_emails.py
├── main.py           # FastAPI app
└── GUIDE.md          # Comprehensive documentation
```

---

## 🔑 Features

✅ **Client Credentials Flow** - No user interaction required  
✅ **Auto Token Refresh** - Automatic before expiry  
✅ **Clean REST API** - Standard JSON responses  
✅ **Audit & Monitoring** - System stats and health checks  
✅ **Production Ready** - Logging, error handling, security

---

## 📚 Documentation

See **[GUIDE.md](./GUIDE.md)** for:
- Complete Azure AD setup
- Database configuration
- API reference with examples
- Deployment guide
- Troubleshooting

---

## 🚀 Usage Example

```bash
# Get next attachment
curl -H "X-API-Key: your-key" \
  http://localhost:5000/api/v1/attachments/next

# Create job
curl -X POST -H "X-API-Key: your-key" \
  -H "Content-Type: application/json" \
  -d '{"attachment_id":"att_123","agent_name":"agent","requested_by":"user"}' \
  http://localhost:5000/api/v1/agent-jobs
```

---

**Version:** 2.0.0  
**Auth Flow:** Client Credentials (Organizational)  
**License:** Internal Use

# Email Attachment Processor - Comprehensive Guide

**Organizational Version** (Client Credentials Flow)

---

## Table of Contents

1. [Overview](#overview)
2. [Features](#features)
3. [Project Structure](#project-structure)
4. [Setup Guide](#setup-guide)
5. [API Reference](#api-reference)
6. [Workflow](#workflow)
7. [Deployment](#deployment)
8. [Troubleshooting](#troubleshooting)

---

## Overview

This system fetches email attachments from **Microsoft Outlook** (organizational accounts) and provides a REST API for processing them with AI agents. It uses **Client Credentials Flow** for authentication (no user interaction required).

### System Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                     SYSTEM FLOW                               │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│   Microsoft Outlook  →  Email Service  →  MySQL Database    │
│   (Unread Emails)        (Fetch & Store)    (Attachments)    │
│                                                               │
│   FastAPI Server  ←  SAP/Agent Backend  ←  API Endpoints    │
│   (REST API)         (Consume)             (JSON Responses)   │
│                                                               │
└──────────────────────────────────────────────────────────────┘
```

---

## Features

✅ **Automatic Email Fetching** - Fetches unread emails via Microsoft Graph API  
✅ **File Storage** - Stores attachments with date-based organization (YYYY/MM)  
✅ **Database Tracking** - MySQL database tracks all attachments and jobs  
✅ **Auto Token Refresh** - Automatic token refresh (no manual intervention)  
✅ **REST API** - Clean REST API with standard JSON responses  
✅ **Must-Have Endpoints** - Core endpoints for attachment processing  
✅ **Audit & Monitoring** - System statistics and health checks  
✅ **Production Ready** - Logging, error handling, security

---

## Project Structure

```
email_processor_org/
├── core/                      # Core modules
│   ├── __init__.py
│   ├── config.py             # Configuration (Pydantic settings)
│   ├── database.py           # Database operations (MySQL)
│   └── auth.py               # Token management (OAuth2)
│
├── services/                  # Business logic
│   ├── __init__.py
│   ├── email_service.py      # Email fetching (Graph API)
│   └── file_service.py       # File storage
│
├── api/                       # API endpoints
│   ├── __init__.py
│   ├── attachments.py        # Attachment endpoints
│   ├── jobs.py               # Agent job endpoints
│   └── audit.py              # Audit/monitoring
│
├── scripts/                   # Utility scripts
│   ├── __init__.py
│   ├── init_db.py            # Database setup
│   ├── auth_setup.py         # Initial authentication
│   └── fetch_emails.py       # Email ingestion
│
├── main.py                    # FastAPI application
├── requirements.txt           # Dependencies
├── .env.example              # Configuration template
├── .env                      # Your configuration (create this)
└── GUIDE.md                  # This file
```

---

## Setup Guide

### Prerequisites

- **Python 3.8+**
- **MySQL 5.7+**
- **Azure AD** - Registered application with API permissions

---

### Step 1: Azure AD Setup

#### 1.1 Register Application

1. Go to [Azure Portal](https://portal.azure.com)
2. Navigate to **Azure Active Directory** → **App registrations**
3. Click **+ New registration**
4. Configure:
   - **Name**: `Email Attachment Processor`
   - **Supported account types**: `Accounts in this organizational directory only`
   - **Redirect URI**: Leave empty
5. Click **Register**

#### 1.2 Copy Credentials

From the **Overview** page, copy:
- **Application (client) ID** → Use as `AZURE_CLIENT_ID`
- **Directory (tenant) ID** → Use as `AZURE_TENANT_ID`

#### 1.3 Create Client Secret

1. Go to **Certificates & secrets**
2. Click **+ New client secret**
3. Add description: `Email Processor Secret`
4. Choose expiration: `12 months` or `24 months`
5. Click **Add**
6. **Copy the Value immediately** → Use as `AZURE_CLIENT_SECRET`

> [!WARNING]
> Copy the secret value immediately! It won't be shown again.

#### 1.4 Add API Permissions

1. Go to **API permissions**
2. Click **+ Add a permission**
3. Select **Microsoft Graph**
4. Select **Application permissions** (not Delegated)
5. Add these permissions:
   - `Mail.Read`
   - `Mail.ReadWrite`
6. Click **Add permissions**
7. Click **Grant admin consent for [Your Organization]**

> [!IMPORTANT]
> Admin consent is required for application permissions to work.

---

### Step 2: Installation

#### 2.1 Clone/Create Project

```bash
cd /path/to/email_processor_org
```

#### 2.2 Create Virtual Environment

```bash
python -m venv venv

# Linux/Mac
source venv/bin/activate

# Windows
venv\Scripts\activate
```

#### 2.3 Install Dependencies

```bash
pip install -r requirements.txt
```

---

### Step 3: Configuration

#### 3.1 Create .env File

```bash
cp .env.example .env
```

#### 3.2 Edit .env File

```env
# Application
DEBUG=true
API_KEY=generate-your-own-secure-key

# Database
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your-mysql-password
DB_NAME=email_attachments

# Azure AD (from Azure Portal)
AZURE_TENANT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
AZURE_CLIENT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
AZURE_CLIENT_SECRET=your-client-secret-value

# Email
MAILBOX_EMAIL=your-email@company.com
MAILBOX_FOLDER=Inbox
MAX_EMAILS_PER_FETCH=50
```

#### 3.3 Generate API Key

```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

Copy the output and use it as `API_KEY` in `.env`.

---

### Step 4: Database Setup

```bash
python scripts/init_db.py
```

**Expected output:**
```
======================================================================
Database Initialization
======================================================================
Host: localhost:3306
Database: email_attachments
----------------------------------------------------------------------
✓ Database 'email_attachments' created/verified
✓ Table 'attachments' created/verified
✓ Table 'agent_jobs' created/verified
----------------------------------------------------------------------
✓ Database initialization completed successfully
======================================================================
```

---

### Step 5: Authentication Setup

```bash
python scripts/auth_setup.py
```

**Expected output:**
```
======================================================================
Authentication Setup - Client Credentials Flow
======================================================================
Timestamp: 2025-12-14T08:00:00Z
----------------------------------------------------------------------
Acquiring access token...
----------------------------------------------------------------------
✓ Token acquired successfully
Expires at: 2025-12-14T09:00:00Z
Expires in: 3599 seconds
Token file: config/token.json
----------------------------------------------------------------------
✓ Authentication setup complete

You can now:
  1. Fetch emails: python scripts/fetch_emails.py
  2. Start API server: python main.py
======================================================================
```

---

### Step 6: Test Email Fetching

```bash
python scripts/fetch_emails.py
```

---

### Step 7: Start API Server

```bash
python main.py
```

Or with uvicorn:

```bash
uvicorn main:app --host 0.0.0.0 --port 5000 --reload
```

**Server should be running at:** `http://localhost:5000`

Visit `http://localhost:5000/docs` for interactive API documentation (Swagger UI).

---

## API Reference

All endpoints require API key authentication via `X-API-Key` header.

### Authentication

```http
X-API-Key: your-api-key-from-env
```

---

### Must-Have Endpoints

#### 1. GET /api/v1/attachments/next

**Get the next attachment for processing (FIFO by default).**

**Query Parameters:**
- `newest_first` (boolean, optional): If true, returns newest first. Default: false

**Request:**
```bash
curl -X GET "http://localhost:5000/api/v1/attachments/next" \
  -H "X-API-Key: your-api-key"
```

**Response (200 - Attachment Available):**
```json
{
  "meta": {
    "request_id": "123e4567-e89b-12d3-a456-426614174000",
    "api_version": "v1",
    "generated_at": "2025-12-14T08:30:00Z"
  },
  "attachment": {
    "attachment_id": "att_20251214_083000_abc123",
    "email_id": "AAMkAGI...",
    "file_name": "invoice.pdf",
    "relative_path": "2025/12/invoice.pdf",
    "email_timestamp": "2025-12-14T08:25:00Z",
    "sender": "vendor@example.com",
    "recipient": "invoices@company.com",
    "flags": {
      "is_read": true,
      "send_to_agent": false
    },
    "status": "ready"
  }
}
```

**Response (204 - No Content):**
No attachments available for processing.

---

#### 2. POST /api/v1/agent-jobs

**Create a job to send attachment to agent.**

**Request Body:**
```json
{
  "attachment_id": "att_20251214_083000_abc123",
  "agent_name": "sap_ai_engine",
  "requested_by": "sap_backend"
}
```

**Request:**
```bash
curl -X POST "http://localhost:5000/api/v1/agent-jobs" \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "attachment_id": "att_20251214_083000_abc123",
    "agent_name": "sap_ai_engine",
    "requested_by": "sap_backend"
  }'
```

**Response (201 - Created):**
```json
{
  "meta": {
    "request_id": "123e4567-e89b-12d3-a456-426614174001",
    "api_version": "v1",
    "generated_at": "2025-12-14T08:31:00Z"
  },
  "job": {
    "agent_job_id": "job_20251214_083100_def456",
    "attachment_id": "att_20251214_083000_abc123",
    "file_name": "invoice.pdf",
    "relative_path": "2025/12/invoice.pdf",
    "send_to_agent": true,
    "agent_name": "sap_ai_engine",
    "status": "queued"
  }
}
```

> [!NOTE]
> This endpoint automatically marks the attachment as `send_to_agent=1` so it won't appear in the "next" queue again.

---

### Additional Endpoints

#### GET /api/v1/attachments/pending

List all pending attachments (not sent to agent).

#### GET /api/v1/attachments/processed

List all processed attachments (sent to agent).

#### GET /api/v1/attachments/{attachment_id}

Get specific attachment by ID.

#### GET /api/v1/agent-jobs

List all agent jobs.

#### GET /api/v1/agent-jobs/{job_id}

Get specific job details.

#### PATCH /api/v1/agent-jobs/{job_id}

Update job status.

**Request Body:**
```json
{
  "status": "completed",
  "result": "Invoice processed successfully",
  "error_message": null
}
```

#### GET /api/v1/audit/stats

Get system statistics.

**Response:**
```json
{
  "meta": {...},
  "attachments": {
    "total": 150,
    "pending": 10,
    "processed": 135,
    "errors": 5
  },
  "jobs": {
    "total": 135,
    "queued": 2,
    "running": 1,
    "completed": 130,
    "failed": 2
  },
  "system": {
    "database": "healthy",
    "token": {
      "status": "valid",
      "expires_at": "2025-12-14T09:00:00Z",
      "acquired_at": "2025-12-14T08:00:00Z",
      "token_type": "Bearer"
    },
    "mailbox": "your-email@company.com",
    "version": "2.0.0"
  }
}
```

#### GET /api/v1/audit/health

Health check (no authentication required).

#### GET /api/v1/audit/token

Get token status and expiration.

#### POST /api/v1/audit/refresh-token

Force token refresh.

---

## Workflow

### Complete Workflow Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                       COMPLETE WORKFLOW                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  1. EMAIL INGESTION (Scheduled - every 5 minutes)               │
│     ┌───────────────────────────────────────────────────────┐   │
│     │ python scripts/fetch_emails.py                        │   │
│     │                                                        │   │
│     │ • Fetches unread emails from Outlook                  │   │
│     │ • Downloads attachments to filesystem                 │   │
│     │ • Stores metadata in MySQL (status='ready')           │   │
│     │ • Marks emails as read                                │   │
│     └───────────────────────────────────────────────────────┘   │
│                              │                                   │
│                              ▼                                   │
│  2. API SERVER (Always running)                                 │
│     ┌───────────────────────────────────────────────────────┐   │
│     │ python main.py                                        │   │
│     │                                                        │   │
│     │ Provides REST API for SAP/Agent backend              │   │
│     └───────────────────────────────────────────────────────┘   │
│                              │                                   │
│                              ▼                                   │
│  3. SAP/AGENT BACKEND (Consumer)                                │
│     ┌───────────────────────────────────────────────────────┐   │
│     │ a. GET /api/v1/attachments/next                       │   │
│     │    → Retrieves next available attachment             │   │
│     │                                                        │   │
│     │ b. POST /api/v1/agent-jobs                            │   │
│     │    → Creates job, marks attachment as sent            │   │
│     │                                                        │   │
│     │ c. Process attachment with AI                         │   │
│     │                                                        │   │
│     │ d. PATCH /api/v1/agent-jobs/{id}                      │   │
│     │    → Updates job status (completed/failed)            │   │
│     └───────────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Typical Usage Pattern

```python
import requests

API_BASE = "http://localhost:5000/api/v1"
API_KEY = "your-api-key"

headers = {"X-API-Key": API_KEY}

# 1. Get next attachment
response = requests.get(f"{API_BASE}/attachments/next", headers=headers)

if response.status_code == 204:
    print("No attachments available")
else:
    attachment = response.json()['attachment']
    attachment_id = attachment['attachment_id']
    
    # 2. Create job
    job_data = {
        "attachment_id": attachment_id,
        "agent_name": "my_ai_agent",
        "requested_by": "backend_service"
    }
    
    job_response = requests.post(
        f"{API_BASE}/agent-jobs",
        headers=headers,
        json=job_data
    )
    
    job = job_response.json()['job']
    job_id = job['agent_job_id']
    
    # 3. Process attachment
    # ... your AI processing logic ...
    
    # 4. Update job status
    update_data = {
        "status": "completed",
        "result": "Successfully processed"
    }
    
    requests.patch(
        f"{API_BASE}/agent-jobs/{job_id}",
        headers=headers,
        json=update_data
    )
```

---

## Deployment

### Scheduling with Cron

#### Email Fetching (every 5 minutes)

```bash
crontab -e
```

Add:
```
*/5 * * * * cd /path/to/email_processor_org && /path/to/venv/bin/python scripts/fetch_emails.py >> logs/emails.log 2>&1
```

---

### Production Server (Gunicorn)

#### Install Gunicorn

```bash
pip install gunicorn
```

#### Run with Gunicorn

```bash
gunicorn main:app \
  --workers 4 \
  --worker-class uvicorn.workers.UvicornWorker \
  --bind 0.0.0.0:5000 \
  --access-logfile logs/access.log \
  --error-logfile logs/error.log
```

---

### Systemd Service

Create `/etc/systemd/system/email-processor.service`:

```ini
[Unit]
Description=Email Attachment Processor
After=network.target mysql.service

[Service]
Type=notify
User=www-data
Group=www-data
WorkingDirectory=/path/to/email_processor_org
Environment="PATH=/path/to/email_processor_org/venv/bin"
ExecStart=/path/to/venv/bin/gunicorn main:app \
  --workers 4 \
  --worker-class uvicorn.workers.UvicornWorker \
  --bind 0.0.0.0:5000
Restart=always

[Install]
WantedBy=multi-user.target
```

Enable and start:

```bash
sudo systemctl enable email-processor
sudo systemctl start email-processor
sudo systemctl status email-processor
```

---

## Troubleshooting

### Issue: "Authentication failed - token may be expired"

**Solution:**
```bash
# Check token status
curl -H "X-API-Key: your-key" http://localhost:5000/api/v1/audit/token

# Refresh token
python scripts/auth_setup.py
```

---

### Issue: "Database connection failed"

**Solution:**
```bash
# Test MySQL connection
mysql -h localhost -u root -p

# Verify database exists
SHOW DATABASES;
USE email_attachments;
SHOW TABLES;

# Re-initialize if needed
python scripts/init_db.py
```

---

### Issue: "No emails being fetched"

**Checklist:**
1. ✅ Azure AD permissions granted (Mail.Read, Mail.ReadWrite)
2. ✅ Admin consent provided
3. ✅ Mailbox email correct in `.env`
4. ✅ Token is valid (check `/api/v1/audit/token`)
5. ✅ Emails exist in mailbox and are unread

---

### Issue: "API key invalid"

- Ensure `X-API-Key` header matches `API_KEY` in `.env`
- Header name is case-sensitive

---

### Debugging Tips

#### Enable Debug Mode

In `.env`:
```env
DEBUG=true
```

This enables:
- Detailed logging
- Swagger UI at `/docs`
- Auto-reload on code changes

#### Check Logs

```bash
# When running directly
python main.py

# With systemd
sudo journalctl -u email-processor -f

# Application logs (if configured)
tail -f logs/app.log
```

#### Test Database Connection

```python
from core.database import db

# Test health
print(db.health_check())  # Should print True

# Test query
stats = db.get_attachment_stats()
print(stats)
```

---

## Quick Reference

### Essential Commands

```bash
# Setup
python scripts/init_db.py
python scripts/auth_setup.py

# Operations
python scripts/fetch_emails.py
python main.py

# Server
uvicorn main:app --port 5000 --reload

# Testing
curl -H "X-API-Key: key" http://localhost:5000/api/v1/audit/health
curl -H "X-API-Key: key" http://localhost:5000/api/v1/attachments/next

# Generate API Key
python -c "import secrets; print(secrets.token_hex(32))"
```

---

## Support

For issues or questions:
1. Check this guide
2. Review API documentation at `/docs` (if DEBUG=true)
3. Check system stats: `GET /api/v1/audit/stats`
4. Check logs for error details

---

**Version:** 2.0.0  
**Last Updated:** 2025-12-14

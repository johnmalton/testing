#!/usr/bin/env python3
"""
API Endpoint Testing Script
Tests critical endpoints every minute to verify server functionality.

Usage:
    python scripts/test_endpoints.py

This script will:
1. Test GET /api/v1/attachments/next (fetch next attachment)
2. Test POST /api/v1/agent-jobs (create job for attachment)
3. Run continuously every 60 seconds
"""
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

import time
import httpx
from datetime import datetime, timezone
from core.config import settings


class EndpointTester:
    """Tests API endpoints continuously."""
    
    def __init__(self, base_url: str = "http://localhost:1948", api_key: str = None):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key or settings.API_KEY
        self.headers = {
            'X-API-Key': self.api_key,
            'Content-Type': 'application/json'
        }
        self.test_count = 0
    
    def log(self, message: str, level: str = "INFO"):
        """Print timestamped log message."""
        timestamp = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
        symbol = {
            "INFO": "ℹ",
            "SUCCESS": "✓",
            "ERROR": "✗",
            "WARNING": "⚠"
        }.get(level, "•")
        print(f"[{timestamp}] {symbol} {message}")
    
    def test_health(self) -> bool:
        """Test health endpoint."""
        try:
            response = httpx.get(f"{self.base_url}/api/v1/audit/health", timeout=10)
            if response.status_code == 200:
                data = response.json()
                self.log(f"Health check: {data['status']}", "SUCCESS")
                return True
            else:
                self.log(f"Health check failed: {response.status_code}", "ERROR")
                return False
        except Exception as e:
            self.log(f"Health check error: {e}", "ERROR")
            return False
    
    def test_get_next_attachment(self) -> dict:
        """Test GET /api/v1/attachments/next."""
        try:
            response = httpx.get(
                f"{self.base_url}/api/v1/attachments/next",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 204:
                self.log("GET /attachments/next: No attachments available (204)", "WARNING")
                return None
            elif response.status_code == 200:
                data = response.json()
                attachment = data.get('attachment', {})
                self.log(
                    f"GET /attachments/next: SUCCESS - {attachment.get('file_name')} "
                    f"(ID: {attachment.get('attachment_id')})",
                    "SUCCESS"
                )
                return attachment
            else:
                self.log(f"GET /attachments/next: Failed ({response.status_code})", "ERROR")
                return None
        except Exception as e:
            self.log(f"GET /attachments/next: Error - {e}", "ERROR")
            return None
    
    def test_create_job(self, attachment_id: str) -> dict:
        """Test POST /api/v1/agent-jobs."""
        try:
            payload = {
                "attachment_id": attachment_id,
                "agent_name": "test_agent",
                "requested_by": "test_script"
            }
            
            response = httpx.post(
                f"{self.base_url}/api/v1/agent-jobs",
                headers=self.headers,
                json=payload,
                timeout=10
            )
            
            if response.status_code == 201:
                data = response.json()
                job = data.get('job', {})
                self.log(
                    f"POST /agent-jobs: SUCCESS - Job created "
                    f"(ID: {job.get('agent_job_id')})",
                    "SUCCESS"
                )
                return job
            else:
                self.log(f"POST /agent-jobs: Failed ({response.status_code})", "ERROR")
                return None
        except Exception as e:
            self.log(f"POST /agent-jobs: Error - {e}", "ERROR")
            return None
    
    def test_get_stats(self) -> dict:
        """Test GET /api/v1/audit/stats."""
        try:
            response = httpx.get(
                f"{self.base_url}/api/v1/audit/stats",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                attachments = data.get('attachments', {})
                jobs = data.get('jobs', {})
                self.log(
                    f"GET /audit/stats: SUCCESS - "
                    f"Attachments (pending: {attachments.get('pending')}, "
                    f"processed: {attachments.get('processed')}), "
                    f"Jobs (total: {jobs.get('total')})",
                    "SUCCESS"
                )
                return data
            else:
                self.log(f"GET /audit/stats: Failed ({response.status_code})", "ERROR")
                return None
        except Exception as e:
            self.log(f"GET /audit/stats: Error - {e}", "ERROR")
            return None
    
    def run_test_cycle(self):
        """Run one complete test cycle."""
        self.test_count += 1
        
        print("\n" + "=" * 80)
        self.log(f"TEST CYCLE #{self.test_count}", "INFO")
        print("-" * 80)
        
        # 1. Health check
        if not self.test_health():
            self.log("Server not healthy, skipping other tests", "WARNING")
            return
        
        # 2. Get statistics
        self.test_get_stats()
        
        # 3. Get next attachment
        attachment = self.test_get_next_attachment()
        
        # 4. If attachment available, create job
        if attachment and attachment.get('attachment_id'):
            self.test_create_job(attachment['attachment_id'])
        else:
            self.log("No attachment to process, skipping job creation", "INFO")
        
        print("-" * 80)
        self.log(f"Test cycle #{self.test_count} completed", "SUCCESS")
        print("=" * 80)


def main():
    """Main function."""
    print("=" * 80)
    print("API ENDPOINT TESTING SCRIPT")
    print("=" * 80)
    print(f"Base URL: http://localhost:1947")
    print(f"Test interval: 60 seconds")
    print(f"Press Ctrl+C to stop")
    print("=" * 80)
    
    tester = EndpointTester()
    
    try:
        while True:
            tester.run_test_cycle()
            
            # Wait 60 seconds before next cycle
            print(f"\n⏳ Waiting 60 seconds before next test cycle...")
            time.sleep(60)
    
    except KeyboardInterrupt:
        print("\n" + "=" * 80)
        print(f"✓ Testing stopped by user after {tester.test_count} cycles")
        print("=" * 80)
    except Exception as e:
        print(f"\n✗ Unexpected error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Database Initialization Script
Creates database and required tables for PostgreSQL.

Usage:
    python scripts/init_db.py
"""
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

import psycopg2
from psycopg2 import sql
from core.config import settings


def create_database():
    """Create database if not exists."""
    # Connect without specifying database
    conn = psycopg2.connect(
        host=settings.DB_HOST,
        port=settings.DB_PORT,
        user=settings.DB_USER,
        password=settings.DB_PASSWORD
    )
    conn.autocommit = True
    
    try:
        with conn.cursor() as cursor:
            # Check if database exists
            cursor.execute(
                "SELECT 1 FROM pg_database WHERE datname = %s",
                (settings.DB_NAME,)
            )
            exists = cursor.fetchone()
            
            if not exists:
                # Create database
                cursor.execute(
                    sql.SQL("CREATE DATABASE {}").format(
                        sql.Identifier(settings.DB_NAME)
                    )
                )
                print(f"✓ Database '{settings.DB_NAME}' created")
            else:
                print(f"✓ Database '{settings.DB_NAME}' already exists")
    finally:
        conn.close()


def create_tables():
    """Create required tables."""
    conn = psycopg2.connect(
        host=settings.DB_HOST,
        port=settings.DB_PORT,
        user=settings.DB_USER,
        password=settings.DB_PASSWORD,
        database=settings.DB_NAME
    )
    
    try:
        with conn.cursor() as cursor:
            # Attachments table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS attachments (
                    id SERIAL PRIMARY KEY,
                    attachment_id VARCHAR(100) NOT NULL UNIQUE,
                    email_id VARCHAR(200) NOT NULL,
                    file_name VARCHAR(255) NOT NULL,
                    relative_path VARCHAR(500) NOT NULL,
                    sender VARCHAR(255),
                    recipient VARCHAR(255),
                    email_timestamp TIMESTAMP,
                    body TEXT,
                    is_read BOOLEAN DEFAULT FALSE,
                    send_to_agent BOOLEAN DEFAULT FALSE,
                    status VARCHAR(50) DEFAULT 'ready',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            print("✓ Table 'attachments' created/verified")
            
            # Create indexes for attachments
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_status_timestamp 
                ON attachments(status, email_timestamp)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_send_to_agent 
                ON attachments(send_to_agent)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_email_id 
                ON attachments(email_id)
            """)
            
            # Agent jobs table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS agent_jobs (
                    id SERIAL PRIMARY KEY,
                    agent_job_id VARCHAR(100) NOT NULL UNIQUE,
                    attachment_id VARCHAR(100) NOT NULL,
                    agent_name VARCHAR(100) NOT NULL,
                    requested_by VARCHAR(100) NOT NULL,
                    status VARCHAR(50) DEFAULT 'queued',
                    result TEXT,
                    error_message TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            print("✓ Table 'agent_jobs' created/verified")
            
            # Create indexes for agent_jobs
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_attachment_id 
                ON agent_jobs(attachment_id)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_status 
                ON agent_jobs(status)
            """)
        
        conn.commit()
    finally:
        conn.close()


def main():
    """Main function."""
    print("=" * 70)
    print("Database Initialization (PostgreSQL)")
    print("=" * 70)
    print(f"Host: {settings.DB_HOST}:{settings.DB_PORT}")
    print(f"Database: {settings.DB_NAME}")
    print("-" * 70)
    
    try:
        create_database()
        create_tables()
        print("-" * 70)
        print("✓ Database initialization completed successfully")
    except Exception as e:
        print(f"✗ Error: {e}")
        sys.exit(1)
    
    print("=" * 70)


if __name__ == "__main__":
    main()

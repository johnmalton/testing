#!/usr/bin/env python3
"""
Automated Email Processing Script
Continuously fetches emails, processes attachments, and sends to agent.

Features:
- Fetches emails every 60 seconds
- Automatically forwards attachments to agent
- Health monitoring
- Auto token refresh every 55 minutes
- Detailed logging

Usage:
    python scripts/auto_email_processor.py
"""
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

import time
import threading
from datetime import datetime, timezone
from services.email_service import email_service
from core.auth import token_manager
from core.database import db
from core.config import settings
import httpx


class AutoEmailProcessor:
    """Automated email processor with continuous operation."""
    
    def __init__(self, base_url: str = "http://localhost:1948"):
        self.base_url = base_url.rstrip('/')
        self.api_key = settings.API_KEY
        self.headers = {
            'X-API-Key': self.api_key,
            'Content-Type': 'application/json'
        }
        self.cycle_count = 0
        self.total_emails_processed = 0
        self.total_attachments_forwarded = 0
        self.running = True
        
        # Token refresh timer
        self.token_refresh_timer = None
        self.start_token_refresh_timer()
    
    def log(self, message: str, level: str = "INFO"):
        """Print timestamped log message."""
        timestamp = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
        symbols = {
            "INFO": "ℹ️",
            "SUCCESS": "✅",
            "ERROR": "❌",
            "WARNING": "⚠️",
            "EMAIL": "📧",
            "AGENT": "🤖",
            "HEALTH": "💚",
            "TOKEN": "🔑"
        }
        symbol = symbols.get(level, "•")
        print(f"[{timestamp}] {symbol} {message}")
    
    def start_token_refresh_timer(self):
        """Start background token refresh timer (every 55 minutes)."""
        if not self.running:
            return
        
        self.log("Token refresh scheduled in 55 minutes", "TOKEN")
        self.token_refresh_timer = threading.Timer(55 * 60, self.refresh_token_callback)
        self.token_refresh_timer.daemon = True
        self.token_refresh_timer.start()
    
    def refresh_token_callback(self):
        """Background callback to refresh token."""
        if not self.running:
            return
        
        try:
            self.log("Auto-refreshing access token...", "TOKEN")
            token_data = token_manager.refresh_token()
            self.log(
                f"Token refreshed successfully! Expires in {token_data['expires_in']}s",
                "SUCCESS"
            )
        except Exception as e:
            self.log(f"Token refresh failed: {e}", "ERROR")
        finally:
            # Schedule next refresh
            if self.running:
                self.start_token_refresh_timer()
    
    def check_health(self) -> bool:
        """Check API server health."""
        try:
            response = httpx.get(f"{self.base_url}/api/v1/audit/health", timeout=10)
            if response.status_code == 200:
                data = response.json()
                status = data.get('status', 'unknown')
                db_status = data.get('database', 'unknown')
                self.log(f"Health: {status} | Database: {db_status}", "HEALTH")
                return status == "healthy"
            else:
                self.log(f"Health check failed: {response.status_code}", "ERROR")
                return False
        except Exception as e:
            self.log(f"Health check error: {e}", "ERROR")
            return False
    
    def fetch_emails(self) -> dict:
        """Fetch and process emails."""
        try:
            self.log("Fetching unread emails...", "EMAIL")
            stats = email_service.process_emails()
            
            self.total_emails_processed += stats['emails_processed']
            
            if stats['emails_processed'] > 0:
                self.log(
                    f"Processed {stats['emails_processed']} emails, "
                    f"saved {stats['attachments_saved']} attachments",
                    "SUCCESS"
                )
            else:
                self.log("No new emails found", "INFO")
            
            return stats
        except Exception as e:
            self.log(f"Email fetch error: {e}", "ERROR")
            return {'emails_processed': 0, 'attachments_saved': 0, 'errors': 1}
    
    def get_next_attachment(self) -> dict:
        """Get next pending attachment from API."""
        try:
            response = httpx.get(
                f"{self.base_url}/api/v1/attachments/next",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 204:
                # No content available
                return None
            elif response.status_code == 200:
                # Parse JSON response
                try:
                    data = response.json()
                    # Ensure data is a dict and has 'attachment' key
                    if isinstance(data, dict):
                        return data.get('attachment')
                    else:
                        self.log(f"Unexpected response format: {type(data)}", "ERROR")
                        return None
                except Exception as json_error:
                    self.log(f"JSON parse error: {json_error}", "ERROR")
                    self.log(f"Response text: {response.text[:200]}", "ERROR")
                    return None
            else:
                self.log(f"Failed to get attachment: {response.status_code}", "ERROR")
                return None
        except Exception as e:
            self.log(f"Get attachment error: {e}", "ERROR")
            return None
    
    def forward_to_agent(self, attachment_id: str, file_name: str) -> bool:
        """Forward attachment to agent by creating a job."""
        try:
            payload = {
                "attachment_id": attachment_id,
                "agent_name": "email_processor_agent",
                "requested_by": "auto_processor"
            }
            
            response = httpx.post(
                f"{self.base_url}/api/v1/agent-jobs",
                headers=self.headers,
                json=payload,
                timeout=10
            )
            
            if response.status_code == 201:
                try:
                    data = response.json()
                    if isinstance(data, dict):
                        job_id = data.get('job', {}).get('agent_job_id')
                        self.log(
                            f"Forwarded to agent: {file_name} (Job: {job_id})",
                            "AGENT"
                        )
                        self.total_attachments_forwarded += 1
                        return True
                    else:
                        self.log(f"Unexpected job response format: {type(data)}", "ERROR")
                        return False
                except Exception as json_error:
                    self.log(f"JSON parse error in job creation: {json_error}", "ERROR")
                    return False
            else:
                self.log(f"Failed to forward: {response.status_code}", "ERROR")
                try:
                    error_detail = response.json()
                    self.log(f"Error details: {error_detail}", "ERROR")
                except:
                    pass
                return False
        except Exception as e:
            self.log(f"Forward error: {e}", "ERROR")
            return False
    
    def get_stats(self) -> dict:
        """Get system statistics."""
        try:
            response = httpx.get(
                f"{self.base_url}/api/v1/audit/stats",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            return None
        except Exception as e:
            self.log(f"Stats error: {e}", "ERROR")
            return None
    
    def process_pending_attachments(self):
        """Process all pending attachments and forward to agent."""
        processed_count = 0
        
        while True:
            attachment = self.get_next_attachment()
            
            if not attachment:
                break
            
            attachment_id = attachment.get('attachment_id')
            file_name = attachment.get('file_name')
            sender = attachment.get('sender')
            
            self.log(f"Found attachment: {file_name} from {sender}", "EMAIL")
            
            # Forward to agent
            if self.forward_to_agent(attachment_id, file_name):
                processed_count += 1
            
            # Small delay to avoid overwhelming the system
            time.sleep(0.5)
        
        if processed_count > 0:
            self.log(f"Forwarded {processed_count} attachments to agent", "SUCCESS")
    
    def run_cycle(self):
        """Run one complete processing cycle."""
        self.cycle_count += 1
        
        print("\n" + "=" * 80)
        self.log(f"PROCESSING CYCLE #{self.cycle_count}", "INFO")
        print("-" * 80)
        
        # 1. Health check
        if not self.check_health():
            self.log("Server not healthy, skipping this cycle", "WARNING")
            print("-" * 80)
            return
        
        # 2. Fetch new emails
        email_stats = self.fetch_emails()
        
        # 3. Process pending attachments and forward to agent
        self.process_pending_attachments()
        
        # 4. Show statistics
        stats_data = self.get_stats()
        if stats_data:
            attachments = stats_data.get('attachments', {})
            jobs = stats_data.get('jobs', {})
            self.log(
                f"System Stats - Pending: {attachments.get('pending')}, "
                f"Processed: {attachments.get('processed')}, "
                f"Jobs: {jobs.get('total')}",
                "INFO"
            )
        
        print("-" * 80)
        self.log(
            f"Cycle #{self.cycle_count} complete | "
            f"Total Emails: {self.total_emails_processed} | "
            f"Total Forwarded: {self.total_attachments_forwarded}",
            "SUCCESS"
        )
        print("=" * 80)
    
    def stop(self):
        """Stop the processor."""
        self.running = False
        if self.token_refresh_timer:
            self.token_refresh_timer.cancel()
        token_manager.stop_auto_refresh()


def main():
    """Main function."""
    print("=" * 80)
    print("🚀 AUTOMATED EMAIL PROCESSOR")
    print("=" * 80)
    print(f"📍 API Server: http://localhost:1948")
    print(f"📧 Mailbox: {settings.MAILBOX_EMAIL}")
    print(f"⏱️  Check Interval: 60 seconds")
    print(f"🔑 Token Refresh: Every 55 minutes")
    print(f"⚡ Press Ctrl+C to stop")
    print("=" * 80)
    
    processor = AutoEmailProcessor()
    
    try:
        while processor.running:
            processor.run_cycle()
            
            # Wait 60 seconds before next cycle
            print(f"\n⏳ Waiting 10 seconds before next cycle...\n")
            time.sleep(10)
    
    except KeyboardInterrupt:
        print("\n" + "=" * 80)
        print(f"🛑 Stopping processor...")
        processor.stop()
        print(f"✅ Processor stopped after {processor.cycle_count} cycles")
        print(f"📊 Total emails processed: {processor.total_emails_processed}")
        print(f"📊 Total attachments forwarded: {processor.total_attachments_forwarded}")
        print("=" * 80)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        processor.stop()
        sys.exit(1)


if __name__ == "__main__":
    main()

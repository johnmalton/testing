#!/usr/bin/env python3
"""
Authentication Setup Script
Acquires initial access token for Microsoft Graph API.

Usage:
    python scripts/auth_setup.py
"""
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from datetime import datetime, timezone
from core.auth import token_manager


def main():
    """Main function."""
    print("=" * 70)
    print("Authentication Setup - Client Credentials Flow")
    print("=" * 70)
    print(f"Timestamp: {datetime.now(timezone.utc).isoformat()}")
    print("-" * 70)
    
    try:
        print("Acquiring access token...")
        token_data = token_manager.refresh_token()
        
        print("-" * 70)
        print("✓ Token acquired successfully")
        print(f"Expires at: {token_data['expires_at_iso']}")
        print(f"Expires in: {token_data['expires_in']} seconds")
        print(f"Token file: {token_manager.token_file}")
        print("-" * 70)
        print("✓ Authentication setup complete")
        print("\nYou can now:")
        print("  1. Fetch emails: python scripts/fetch_emails.py")
        print("  2. Start API server: python main.py")
        
    except Exception as e:
        print(f"✗ Error: {e}")
        print("\nPlease check:")
        print("  1. Azure AD credentials in .env file")
        print("  2. App permissions (Mail.Read, Mail.ReadWrite)")
        print("  3. Admin consent granted")
        sys.exit(1)
    
    print("=" * 70)


if __name__ == "__main__":
    main()
